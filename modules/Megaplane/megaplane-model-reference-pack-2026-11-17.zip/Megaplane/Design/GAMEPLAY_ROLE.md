# BREAKWATER — the flying invasion hub

**Design stage:** concept and gameplay specification only. **User-required role:** rapid invasion / reaction-force carrier with infantry, aerial and ground drones, onboard artillery, AWACS, rearming and refueling. These capabilities form one combined role; they are not mutually exclusive loadout modes.

## Purpose

**Bring a force, establish a foothold, keep it fighting, and recover the survivors.**

BREAKWATER bridges the gap between gaining access to an area and establishing an ordinary, sustainable supply network. It arrives with a finite expedition, supports its landing and ground fight, and supplies additional sorties while a captured base or ground supply route comes online. When the faction no longer needs its mobile support, it can reinforce another location or withdraw to replenish.

Success is measured through ground objectives held, useful sorties sustained, supplies actually delivered and personnel/craft recovered. Merely orbiting an objective does not capture it, refill allies or grant omniscient vision.

## Every requested capability has a job

| Capability | Contribution to the invasion | Interaction and limitation |
| --- | --- | --- |
| **Infantry** | Establish occupied positions, contribute to capture through the supported ground mechanics, defend service locations and remain after the carrier moves away. | Personnel must actually reach the objective. Carrying troops overhead grants no extra carrier capture effect. Current infantry representation uses native positions/emplacements; independent soldier AI is a separate development question. |
| **Aerial drones** | Provide organic reconnaissance, a small escort/strike element and observation for support. | A finite embarked fleet with identifiable craft, stores and damage. Launch, recover and service them; no continuous free replacement spawner. |
| **Ground drones** | Give the landing force reconnaissance, fire support and local supply movement. | Deliver actual native vehicles through a valid landing/drop method. Vehicle roles and capture contribution follow the chosen native definitions; no invisible damage or capture effects. |
| **Onboard artillery** | Keep supporting the foothold after the first attack aircraft have departed. | A real carrier-mounted gunship/artillery battery with native projectiles, finite stores, firing geometry and observable effects. It is not an orbital Support call wearing a carrier icon. |
| **AWACS** | Build the faction's air picture, warn the expedition and help coordinate escorts and sorties. | Native sensors and faction tracking, with detection, terrain, jamming, age and emission limits. It is useful because it sees from its actual position. |
| **Rearm and refuel** | Turn embarked supplies into additional allied sorties and sustained drone/ground activity. | Real service interfaces, compatible stores, finite stocks and transfer time. Fission provides energy, not replacement ammunition or transferable liquid fuel. |
| **Carrier mobility** | Move an expedition without waiting for a permanent base, reinforce a crisis or recover a spent force. | Large turns, route access, changing service geometry, damage and the need to replenish remain costs. |

## The operating loop

1. **Prepare.** Assign a destination and embark a mixed force, compatible supply stocks and handling equipment. Select useful stock priorities while retaining every required function. Show what the expedition can actually sustain.
2. **Open the route.** Existing players/AI provide escorts, reconnaissance and suppression as required. The carrier follows an achievable route and chooses a working track from known threats, aircraft handling and support reach.
3. **Arrive and establish the picture.** The carrier's sensors begin contributing real tracks. Launch a bounded aerial element and prepare the first delivery. AWACS, self-protection and available onboard support remain active together.
4. **Deploy.** Shuttles, suitable drops or supported delivery craft move infantry, ground drones and service kits to a viable location. The carrier remains wing-borne; it does not hover over the landing zone or teleport the manifest ashore.
5. **Take and hold.** Deployed capture-capable ground elements follow the mission's capture process. Defenders can contest the location. Onboard artillery, drones and other faction aircraft support that fight from actual available positions and stocks.
6. **Sustain.** Deliver supplies to the foothold, cycle compatible aircraft through service, rotate damaged drones and reinforce ground positions. Decide whether to spend reserves expanding the operation or retain enough for extraction and another task.
7. **Hand over, reinforce or recover.** A captured base or arriving ground supply network can take over. Recover physically reachable survivors and equipment, leave useful supplied forces behind, or redeploy the carrier. No recovery button silently restores the manifest.

## Service contexts

**Airborne servicing** supports compatible allied aircraft through a defined relative-flight service interface. Refuel and rearm are separate requests, and service depends on speed, geometry, compatibility, stocks and a free handling channel. The carrier must fly a validated service track. Its nominal 180 m/s cruise must not be assumed compatible with the current SKYWELL service envelope.

**Onboard recovery/service** admits purpose-built small craft to a measured cradle or bay. Recovery, physical securing, servicing and relaunch are distinct steps. Returning a damaged drone does not create a pristine replacement.

**Ground servicing** uses delivered equipment at a secured, suitable location. Fuel and ammunition are delivered to that location's ledger; native service functions consume those stocks through an appropriately validated integration. This is how the carrier supports aircraft and ground vehicles that cannot use its airborne interface.

Large aircraft do not automatically fit inside the bay, and a friendly unit passing nearby receives nothing. The role includes allied servicing; supported interfaces and airframes must be chosen and proven rather than assuming universal compatibility.

## How the player commands it

The default gameplay assumption is an **AI-flown faction asset with an authorized player commander**, so one player can operate the expedition without manually flying every vehicle. A later player-pilot role can coexist with the commander after the native flight and service tracks are demonstrated. Multiplayer crew seats are optional, not a requirement to use the carrier.

Commander intents are operation-level: set the working area, deploy a ground element, assign an aerial element, request fire support, prioritize service stocks, recover an element, or withdraw. Native AI and validated handlers execute the details. Ground-force relocation requires actual supported movement or pickup/reinsertion; changing a map marker cannot move an occupied position.

Use existing Command/OPS/Wing interaction language where appropriate, with a compact carrier operation view and existing aircraft controls. Display the expedition's consequential state: deployment progress, observed situation, aircraft service queue, force status, stock shortages and recovery commitments. Do not require a separate dashboard for every technology in the aircraft.

All capabilities can operate together when their actual resources and geometry permit. One shared bay can queue two incompatible handling jobs; that does not arbitrarily disable radar or artillery. A low ammunition stock affects the relevant weapon, not every support function.

## Onboard fire support and AWACS

The artillery requirement is **a carried, damageable battery**, not merely permission to order remote artillery. Its future implementation must launch from the carrier through supported native weapon behavior and debit its own ammunition. Carrier attitude, mount reach and friendly proximity can prevent a shot; the aircraft can reposition for a firing opportunity. No weapon construction or ballistic design is specified here.

A known map point or observer report may support a fire request; hidden world objects are not a valid source of targeting knowledge. AWACS contributes air surveillance, while ground identification depends on suitable sensors, scouts or observations. Track confidence and age remain meaningful when the carrier turns radar off, loses equipment, leaves coverage or is jammed.

The carrier can coordinate support without automatically inheriting every existing OPS discount or spawning an extra strategic economy. Any benefit must follow a deliberate shared contract and the relevant module's policy.

## Why the rest of the faction still matters

- Escorts keep the carrier and its small deployed force operational. Its point defense does not automatically protect an entire region.
- Dedicated fighters and attackers deliver responsive firepower beyond its finite drone wing and gunship geometry.
- Transport and logistics aircraft replenish the expedition and move assets that its available shuttles cannot handle.
- Ground forces secure objectives and service locations. Aerial superiority alone cannot complete the invasion.
- Permanent bases and ground supply routes provide sustained volume. The carrier's force and stores are expedition capacity, not an unlimited factory.

The opponent can disrupt the operation without destroying the flagship: contest the foothold, reduce the deployed force, damage sensors or handling equipment, interrupt delivered supplies, or force the carrier off its useful track. Carrier damage has functional consequences rather than arbitrary boss phases.

## Mission placement and shared ownership

Study one carrier per participating faction, with the scenario deciding which factions receive one. This is a starting balance fixture, not a proven performance limit. It is a faction asset rather than a fresh full manifest for every player. Scenario progression or a deliberate purchase/dispatch process can govern availability later; no price, rank or ordinary hangar entry is defined now.

An operation should expose its force and stock commitments before dispatch. Replenishment requires actual delivered supplies or a suitable rear-base service process. Changing commander, opening a UI or beginning a second objective cannot reset the starting manifest.

## Example play

**Reaction force:** a friendly objective is losing its service capability. BREAKWATER arrives with cover, adds observed air tracks, launches a small drone element and delivers infantry, ground support and a limited service packet. The ground force secures the location while the carrier contributes finite onboard fire support. Compatible allies replenish. The useful result is an objective that can keep operating after the carrier departs.

**Invasion:** players prepare the mixed manifest and open an approach. The carrier deploys the first ground element, supports the contested capture and then delivers service equipment and stocks. Damaged drones return, ground drones move supplies and follow-on aircraft bring replacements. The commander chooses how much reserve to commit before the captured base or ground supply network takes over. The foothold can survive the carrier's departure if it has actual forces and supplies.

## What must survive the prototype

A convincing prototype must demonstrate one complete loop: deploy a real ground element, capture through supported mechanics, expend real ammunition, perform finite service, and recover or leave behind survivors with correct inventories. It must include infantry, both drone domains, onboard artillery, observed AWACS tracks and service roles before claiming the full invasion-carrier feature is complete. Development can be staged, but a staged subset is not the finished role.

The [embarked-force specification](EMBARKED_FORCE.md) defines the initial manifest, bookkeeping and lifecycle. The [integration audit](../Research/07-gameplay-integration.md) distinguishes existing building blocks from new carrier behavior.
