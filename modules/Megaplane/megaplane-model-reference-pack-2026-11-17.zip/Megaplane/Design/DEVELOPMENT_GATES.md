# Development gates — future work, not executed tasks

Research and concepts are the completed scope of this module's initial stage. The gates below are a handoff for a later implementation request. No unchecked item is evidence of a working feature.

The expanded setting direction is the [2055 fission flagship](SYSTEMS_2055.md). The following nuclear/system gates precede detailed production:

- [ ] Close a complete installed mass/volume ledger for reactor, shielding, supports, containment, exchangers, thermal transport, accessories, cooling and service access. Do not infer airborne suitability from terrestrial fission maturity.
- [ ] Compare the preferred indirect airbreathing cycle with the electric alternative using consistent useful power, pressure losses, accessory demand, cooling drag and mass. The illustrative 1,500 MWth case is bookkeeping, not a selected plant.
- [ ] Establish radiation protection and allowable occupancy using a qualified analysis of full aircraft geometry and operating conditions; a concept drawing supplies no dose evidence.
- [ ] Analyze reactor trip, residual/stored heat, loss of propulsion airflow, hard landing, ground operation and damaged cooling. Chemical-only contingency performance and independent essential power need separate budgets.
- [ ] Validate passive wing integrity, active load control and sensor/actuator failures together. Adaptive controls do not guarantee survival after arbitrary damage.
- [ ] Define the high-level protection layers, resource/cooling limits and native-game integration scope. Keep DIRCM, physical interception and passive damage absorption distinct; no force-field behavior is implied.
- [ ] Revise geometry and operating envelope if the complete system cannot fit. Retain a conventional demonstrator as a comparison rather than silently assuming a completed nuclear installation.

## G0 — choose the operating problem

- [ ] Validate the adopted [invasion/reaction-force role](GAMEPLAY_ROLE.md) in a first mission and faction context. Default assumption: AI-flown shared faction carrier with an authorized commander; optional player piloting needs separate acceptance.
- [ ] Confirm the silhouette direction and scale. Keep G-240 and BREAKWATER provisional until then.
- [ ] Decide whether runway operation is essential and select a first integration slice. The full role still requires infantry, aerial/ground drones, onboard artillery, AWACS and rearm/refuel together.
- [ ] Agree on a minimum operation: native air-start, sustained flight, a navigable turn and meaningful damage. Launch/recovery and a walkable interior remain separate milestones.

## G1 — prove that the world has room

- [ ] Measure map boundaries, useful altitude, a representative route, terrain clearance and a complete turn using the study's radius.
- [ ] Measure actual runway width/length, adjacent obstacles, taxi curves, spawn transforms, apron and hangar envelopes; test parked and banked clearance.
- [ ] Inspect installed game aircraft types, large native complex-physics vehicles and available donor components with `nomod code context`, `code members`, `code source` and `code refs`.
- [ ] Record game build and source checkout. Decide whether a dedicated air-start route is sufficient if existing infrastructure cannot fit the aircraft. Do not silently shrink the art or enable it in every hangar.

Deliverable: surveyed route/airfield drawings and a donor/component decision with unresolved incompatibilities listed.

## G2 — native physics mule before detailed art

- [ ] Under future implementation authorization, use simple geometry at the intended scale; do not globally scale a donor prefab.
- [ ] Establish mass, inertia, COM, registered airfoils, aerodynamic surface areas/centers and nonzero collision bounds before native initialization.
- [ ] Demonstrate climb, trim, sustained level flight, low-speed recovery and bounded-bank turns using native controls. Record actual fuel/loadout and atmosphere.
- [ ] Test one engine group lost, asymmetric thrust and representative part damage; ensure no NaN forces, explosive contacts or restored lost authority.
- [ ] Decide whether AI can navigate the route. If player control is intended, demonstrate native seating, cockpit, input and camera behavior separately.

Deliverable: exact-artifact telemetry and failure notes. No post-spawn position/velocity overwrite or injected force may stand in for flight acceptance.

## G3 — original production asset

- [ ] Review silhouette and structural cutaway at real scale before detail; preserve human-size pilot and cockpit anchors.
- [ ] Build in metres with verified Blender axes, positive unit export scale, documented hierarchy and measured hinges.
- [ ] Define damage islands, gear, nacelles, control surfaces, bay doors and mission anchors together; inspect full motion and swept clearances.
- [ ] Choose explicit triangle, renderer, material, texture-residency and LOD budgets after native census and the mule's measurements. Initial planning caps are not performance evidence.
- [ ] Reserve texel density for cockpit and close service areas. Inspect mip behavior, repeated materials and large-surface shading at near, interception and map distances.
- [ ] Pass mesh and mechanical audits, inspect front/side/three-quarter/low/wire review sheets, export/reimport FBX, then normalize metric Unity geometry and inspect loaded bundle readback.
- [ ] Keep original art separate from donor-reference extraction; no native meshes/textures in the shipped artwork dependency graph.

Deliverable: editable source, export, asset contract, review images and measured reports. A good render does not establish flight.

## G4 — runtime lifecycle and service

- [ ] Give aircraft key, network prefab hash and loadout order unique stable identities; register after required catalogues are ready.
- [ ] Complete native ownership, HQ rules, purchase or mission spawn, controls, sensors, fuel, cameras, ejection and cleanup.
- [ ] Exercise landing/rearm only if that operation is supported; test real acquisition and weapon expenditure for any chosen defensive installation.
- [ ] Test part health, detachment, child renderers/LODs/effects/colliders and cockpit switching. Rehost and reseat to test destruction and reconstruction.
- [ ] Validate original status silhouette and part masks if native status UI is used.

## G5 — mission operation and invasion support

This is a staged implementation gate for the now-required invasion role; only additional retrieval methods or walkable interiors are optional.

- [ ] Start with one payload type and explicit mass accounting. Confirm release authority, aircraft-relative clearance, door interlocks and behavior when damaged.
- [ ] Test payload release during turn, engine failure and network delay; measure clean separation with both aircraft's collision shapes and velocities.
- [ ] If retrieval is desired, write a separate capture-envelope, relative-speed, authority, docking, abort and respawn design before implementing it.

### Full invasion-role acceptance

- [ ] Close the [300 t embarked manifest](EMBARKED_FORCE.md) against measured component mass, volume, COM, service geometry and electrical/thermal demands. Keep export fuel separate from carrier contingency fuel and avoid double-counting initial loaded stores.
- [ ] Demonstrate infantry deployment and survivor conservation through a supported native position/capture representation. Insertion observation, cosmetic soldiers and objective capture are distinct evidence.
- [ ] Deploy both aerial and ground drone types with finite identities, delegated host-authorized commands and actual terrain/launch handling. Arrival near the bay is not recovery.
- [ ] Fire a real onboard native weapon from the carrier, debiting its magazine; do not substitute orbital-style OPS effects.
- [ ] Demonstrate actual radar/sensor events and faction tracking for AWACS, including stale/unknown information, disabled emissions and damaged sensors.
- [ ] Establish a service track compatible with real aircraft handling. The current SKYWELL speed limits do not support the 180 m/s cruise assumption unchanged.
- [ ] Demonstrate partial stock-bound fuel transfer, typed compatible rearm, depot replenishment, separate service channels and interruption receipts without duplication. Existing native/SKYWELL fill calls do not establish conservation.
- [ ] Verify casualty/recovery overflow, drone damage persistence, supplies delivered to ground service, and deployed survivors continuing after carrier retreat/destruction.
- [ ] Verify that handovers and replacement carriers retain aggregate faction expedition counts, and native position templates do not create unaccounted weapons/ammunition.
- [ ] Test a complete foothold operation and a reaction mission with all required roles available. Functional support, useful player decisions, bounded simulation and ordinary faction logistics must all remain observable.

## G6 — peers, visual acceptance and cost

- [ ] Run same-build real host/client checks for spawn, ownership, damage and every custom state. Include late join, reconnect, authority transfer and rejected invalid intent where relevant.
- [ ] Use feature assertions as well as transport smoke. Record exact DLL, bundle, scenario and game fingerprints; local two-game proof is not a long-latency soak.
- [ ] Inspect actual cockpit and external gameplay captures in clear/day, night and representative weather, with and without damage and near an ordinary aircraft.
- [ ] Measure CPU/GPU frame-time, memory, load cost, draw calls and network traffic in a representative busy mission, comparing the same mission without the plane. Include multiple planes and debris only if that is intended use.
- [ ] Report build/symbol checks, native-flight tests, image review, multiplayer and performance as separate evidence categories.

Only after the relevant gates pass should a future change decide default availability, packaging or public deployment. This dossier does not make those decisions.
