# Embarked force, logistics and lifecycle

**Status:** proposed first balance fixture, not measured payloads or implemented behavior. All values are tuning hypotheses. [invasion-role-parameters.json](../Concepts/invasion-role-parameters.json) records them as study data.

The existing 2055 aircraft ledger reserves **300 t mission payload**. The breakdown below replaces that generic line with a complete mixed invasion package. It does not add 300 t to the 2,400 t aircraft ceiling. The aircraft's 250 t chemical contingency reserve and 50 t defensive-equipment allowance remain separate.

## Reference mission manifest

| Embarked allocation | Study mass | Functional content / boundary |
| --- | ---: | --- |
| Expedition infantry and field equipment | 32 t | 128 personnel represented by 16 eight-person squad records, with personal/deployment equipment, initial infantry/position weapons and their starting ammunition, and field support allocation. Primary aircraft crew are in the base aircraft ledger. |
| Loaded aerial drone fleet | 24 t | 12 small craft, initially allocated as four reconnaissance, four combat-support and four utility/reserve craft. Initial carried energy/stores count in this loaded-fleet allowance. Roles and actual definitions need validation. |
| Loaded insertion / recovery shuttles | 20 t | Two purpose-built carriers: shuttle hardware and their own initial operating consumables only. Excludes transported infantry, vehicles and supplies, which stay in their own lines. These are future assets, not a claim that existing aircraft already fit. |
| Loaded ground drone fleet | 16 t | Eight small native-vehicle-based craft: two reconnaissance, two fire-support and four logistics/support roles. Initial energy and ammunition count here. |
| Onboard artillery mission installation | 20 t | Mounted mission battery, feeds and support hardware. Its ammunition is accounted below. Separate from point-defense equipment. |
| AWACS / mission-command equipment | 12 t | Mission sensors, processing and communication equipment beyond baseline flight avionics. It does not duplicate the primary crew/avionics allowance. |
| Transferable fuel | 70 t | Fuel available for allied service and expedition resupply, distinct from the carrier's protected contingency reserve. |
| Additional ammunition stock | 48 t | Typed reload stocks and the carrier artillery's initial magazine. Excludes initial infantry/position, drone and vehicle stores already counted in their loaded packages. No generic infinite handoff token. |
| Ground service, communications and delivery kit | 24 t | Deployable service equipment and stock-handling hardware. Fuel/ammunition in its containers are counted in the relevant stock lines, not again here. |
| Spares, medical and campaign consumables | 20 t | Finite support stores; service time and actual compatibility remain required. |
| Packaging / mission handling allowance | 14 t | Mission-specific containers and handling provisions, distinct from base aircraft utilities. |
| **Total** | **300 t** | Mass, volume, COM, rack fit and handling remain unverified. |

The categories prevent free resources, not establish component weights. In particular, 24 t divided among twelve loaded drones is an allocation rather than a measured Vanguard drone mass. A later measured manifest must replace these assumptions without double-counting tanks, magazines or handling equipment.

## First simultaneous-entity study limits

| Family | Initial ceiling per carrier | Meaning |
| --- | ---: | --- |
| Carrier | 1 | Scenario-owned shared faction asset. |
| Independently active aerial drones | 4 | From the finite fleet of twelve, not four free replacement slots. |
| Active shuttles | 2 | Separate from the combat/recon drone ceiling. |
| Active ground drones | 8 | The entire finite embarked vehicle fleet could be ashore. |
| Infantry squad records | 16 | All 128 personnel remain accounted. |
| Physical infantry position records | 8 | Each can hold up to two squad records; combat/capture must use supported native representations. This is not 128 independently simulated infantry agents. |
| Concurrent external service channels | 2 | Geometrically separated, compatible service jobs; full implementation must establish safe use. |
| Drone bay service jobs | 1 | A recovered compatible craft can be serviced while an external receiver is served if hardware/resources permit. |
| Pending operation requests | 16 | Bounded host queue; visible refusal/queue state at capacity. |

These ceilings are a performance/balance experiment, not established safe limits. They also define the initial **aggregate faction expedition budget** for carrier-origin units: four active aerial drones, two shuttles, eight ground drones, eight physical infantry positions and sixteen squad records. Handed-over deployed units and survivors from a previous carrier continue counting against that budget until genuinely recovered/deactivated or lost. Changing controller or dispatching another carrier cannot free a slot. This does not assume an existing universal cap on all native faction units; that aggregate expedition accounting is new required behavior.

Other applicable scenario/module caps still apply. Reaching a cap must queue/refuse further deployment; it must not delete existing units or convert reserve units into invisible combat effects. A missing legal representation is an unavailable operation, not permission to fake an effect.

## Conservation rules

Every personnel record, craft and supply quantity must have one authoritative owner/location. Proposed states are **aboard**, **reserved**, **in transit**, **deployed/delivered**, **returning**, **recovered**, **lost/consumed**. A reservation is an encumbrance on existing stock, not extra stock. Recovered items must re-enter the aboard ledger once and retain their actual condition.

- A deployment debits the embarked item only when the authorized transfer commits. A failed preparation releases its reservation.
- Transit loss loses its carried payload; the destination receives only what actually arrives.
- Recovering a craft returns that identity, remaining stores, energy and damage. It does not restore ammunition, fuel or health.
- Infantry recovery returns recorded survivors up to receiving capacity. Overflow remains at the origin or is an explicit loss/outcome; it cannot disappear or multiply into a default full squad.
- A unit transferred into a faction's normal force leaves the carrier's local command ledger through an explicit handover, but remains in the aggregate faction expedition budget described above. It remains a real unit, not a second copy or a newly free deployment slot.
- Initial infantry/emplacement weapons and starting ammunition come from the 32 t infantry package. Creating a native position from a template must not create an additional unaccounted full magazine. Later reloads debit the 48 t typed stock.
- Initial, received, consumed, transferred and lost quantities must reconcile. Client reconnects, commander changes, retries and UI requests do not generate supplies.

Use unique operation receipts, bounded pending work and scene/faction identity checks to make interrupted or repeated requests resolve once. This describes required behavior without predefining C# contracts or a wire format.

## Servicing rules

**Fuel:** the receiver's actual accepted quantity and source debit must agree. The host cannot top off a large receiver from a nearly empty stock and merely clamp the source to zero. Partial delivery is required, or the request must remain uncommitted when the native seam cannot express a partial transfer. Show the amount available before the pilot commits to the approach.

**Ammunition:** debit compatible typed stores for what is actually added. A complete cassette/weapon kit is a legitimate stock unit if it explicitly represents that complete compatible reload; one generic token cannot replenish arbitrary gun magazines and unrelated weapons. Cargo/troop stores cannot be refilled as though they were ordinary ammunition. Faction eligibility and native economic charges still follow their owning policy.

**Drone energy/service:** recharging supported craft consumes electrical capacity, cooling and time. Chemical fuel and ammunition remain finite. Repair uses spares and an appropriate secured service state; it cannot rebuild a destroyed airframe or grow a replacement drone from reactor output.

**Ground service:** transfer supplies into a local, independently owned depot/vehicle ledger before that equipment dispenses them. A carrier transfer and a ground rearmer request cannot both reserve the same stock. Losing communications does not remotely remove delivered supplies from the ground.

**Priorities:** emergency fuel, prepared mission aircraft or another policy can order the queue, but the rules must be visible and consistent across clients. An authorized commander may prioritize a service job; the receiver still chooses/flies a compatible service approach. The carrier should not seize another player's flight controls.

## Deployment and capture

Infantry and ground vehicles require supported delivery geometry and an actual valid destination. The carrier does not land on an ordinary small pad to make this work. Use shuttles, supported drops or suitable native delivery assets, with cargo mass and COM changes accounted for.

Ground forces must reach and participate in the supported capture/occupation system. An airborne manifest cannot apply the same strength to the ground. Moving an occupied infantry position requires actual supported movement or pickup/reinsertion; cosmetic walking does not establish movement or independent squad combat.

Capture, garrison creation and service-site establishment remain separate outcomes. A delivery can arrive successfully while the objective remains contested. Local service can be destroyed even if the faction still holds the objective.

## Lifecycle and adversarial cases

| Event | Required outcome |
| --- | --- |
| Carrier retreats | Physically recover reachable assets; deployed survivors and delivered supplies remain ashore. Cancel unsupported future service/deployment commitments. |
| Carrier destroyed | Lose embarked/reserved stock not already delivered. Independently deployed survivors continue with their remaining resources and supported orders. Do not despawn the entire expedition. |
| Launch or transfer interrupted | Resolve ownership from the committed receipt and actual participants. No credit on both sides and no lost reservation that blocks the queue forever. |
| Service receiver destroyed/disconnects | Preserve the true consumed/transferred quantity and free the handling slot. Rejoining does not repeat the completed transfer. |
| Carrier pilot disconnects | Transfer flight responsibility under the chosen faction/AI rule; do not freeze the plane. AI takeover capability itself needs validation. |
| Commander disconnects | Existing orders continue or enter a defined hold/recovery policy. Another authorized commander can take over the same expedition. |
| Faction changes or carrier captured | Reject stale orders and apply an explicit ownership/handover rule. Never silently credit both factions. |
| Late join | Receive current inventory, craft/position identities, losses, queues, damage and order revisions. Never reconstruct from the starting manifest. |
| Foothold lost | Surviving ground assets remain subject to their actual ownership and combat state. Local service availability depends on the surviving equipment and supply ledger. |
| Mission reset | End the old scene's operations, release owned services and initialize a new scenario ledger exactly once. |

The fission plant remains a power source. Carrier damage must use the selected native damage behavior; this role does not add an automatic nuclear-weapon explosion on reactor loss.

## Acceptance evidence for the role

Later tests should verify a complete expedition and interrupted variants, including: exactly-once deployment; observed AWACS tracking; real onboard fire; native capture; partial finite fueling; compatible reload debits; personnel overflow on recovery; damaged drone return; delivered assets surviving carrier loss; permission rejection; and same-build host/client/late-join agreement. A transport smoke or a clean build alone does not establish these behaviors.
