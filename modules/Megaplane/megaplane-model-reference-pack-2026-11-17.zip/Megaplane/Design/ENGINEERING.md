# Engineering notebook — what this scale costs

**Case label:** original conventional reference. Its 700 t fuel / 400 t payload / eight equal-engine assumptions do not describe the current 2055 fission variant. See [SYSTEMS_2055.md](SYSTEMS_2055.md) and [2055-study-parameters.json](../Concepts/2055-study-parameters.json) for that separate case. The geometry and clean-airframe calculations remain useful comparisons, subject to changed installed drag and mass.

These are reproducible first-order checks, not aerodynamic, structural or airworthiness validation. All aircraft inputs are invented study assumptions from [study-parameters.json](../Concepts/study-parameters.json). Do not treat them as measured Nuclear Option coefficients or as the specifications of an existing aircraft.

## Mass and wing sizing

The study allocates 1,300 t empty/installed equipment, 700 t fuel and 400 t payload, totaling 2,400 t. This is a bookkeeping budget. It does not establish that a structure of this mass can be built, that the fuel fits, or that any useful range follows. Use metric tonnes (1 t = 1,000 kg) throughout; historical sources using tons require explicit conversion.

At 240 m span and 7,200 m² reference wing area:

| Quantity | Calculation | Result |
| --- | --- | --- |
| Aspect ratio | `b² / S` | 8.0 |
| Mass per wing area | `m / S` | 333.3 kg/m² |
| Weight | `m g` | 23.536 MN |
| Cruise dynamic pressure | `0.5 rho V²`, rho = 0.66 kg/m³, V = 180 m/s | 10,692 Pa |
| Required level-flight lift coefficient | `m g / (q S)` | 0.306 |
| Illustrative sea-level stall speed | `sqrt(2 m g / (rho S CLmax))`, rho = 1.225, CLmax = 1.6 | 57.75 m/s (208 km/h) |
| Illustrative approach reference | `1.3 Vs` | 75.08 m/s (270 km/h) |

The lift relation is from [NASA Glenn's lift equation](https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/lift-equation/). CLmax is unmeasured, so the stall result is a sensitivity check. At CLmax 1.2 the corresponding stall speed rises to approximately 66.7 m/s; at 2.0 it falls to approximately 51.7 m/s. Compressibility, Reynolds number, local stall, trim and control authority need their own analysis.

## Drag and propulsion

Use the basic parabolic polar only for a sanity check:

`CDi = CL² / (pi AR e)`; `CD = CD0 + CDi`; `D = q S CD`.

With e = 0.8 and CD0 = 0.022, CDi is 0.00465, total drag approximately 2.05 MN and lift/drag approximately 11.47. The relation and reference-area consistency are documented by [NASA Glenn](https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/induced-drag-coefficient/). At the same point, changing CD0 to 0.03 raises drag to about 2.67 MN. Open bays, stores and separated flow can invalidate the assumed polar.

Eight hypothetical 500 kN engines give 4 MN static installed thrust, a static thrust/weight ratio of about 0.17. **Static sea-level thrust is not available cruise thrust.** This study contains no engine deck, thrust lapse, installation loss, fuel consumption, cooling or engine-out climb analysis. The apparent numerical margin therefore proves nothing about cruise or takeoff capability. No engine product has been selected.

Propulsion sizing must include yaw from a failed outboard engine group, fan/nacelle clearance, intake flow at high incidence, exhaust interaction with the release bay, and any power extraction for mission equipment. Do not obtain flight by multiplying a donor engine's force without a corresponding mass, fuel and control analysis.

## Structure and mass distribution

Geometrically scaling an aircraft by k grows area as k² and volume/mass as k³ if materials and proportions remain alike. At fixed speed the lift demand therefore grows faster than area; real redesign must change wing loading, structure, speed or mass distribution. A large wing also has longer bending lever arms. A visually enlarged small aircraft is not a structural design.

Span-distributed cargo is worth examining: NASA's [1976 spanloader study, CR-145034](https://ntrs.nasa.gov/citations/19760026098) studied cargo carried within a thick wing. It remains a design study rather than proof for this configuration. Our interpretation is to reserve both structural depth and usable inner-wing volume early, and compare load distributions before freezing the hangar.

Required future mass cases: empty, fuel-full, fuel-low, maximum payload, asymmetric release, failed engine group, damaged outer wing, gear extended and emergency landing. Moving 100 t through 40 m within a constant 2,400 t aircraft shifts total center of mass by about 1.67 m. Releasing that mass has a different denominator and must be calculated separately. A decorative COM anchor does not establish balance.

Structural analysis must cover wing-root bending/torsion, aeroelastic divergence and flutter, gust loads, landing impacts, asymmetric damage and bay cutouts. [NASA's long-wing testing work](https://www.nasa.gov/aeronautics/nasa-boeing-test-aircraft-wings/) is a useful reminder that flexible-wing dynamics require dedicated investigation. The rigid game model cannot certify these effects.

## Handling, routes and landing

For a coordinated level turn, `R = V² / (g tan(bank))`. At 180 m/s and 15° bank, R is about **12.33 km**: a full circle is roughly 24.66 km across and takes about 7.2 minutes. At 140 m/s with the same bank the radius is about 7.46 km. The mission must provide room to turn, approach and leave the map boundary safely.

At 20° bank a tip 120 m from the centerline moves vertically about 41 m relative to the roll center before accounting for dihedral, wing flex or terrain. This makes casual sea-skimming banked flight implausible. Ground effect depends on geometry and surface proximity; it cannot be assumed to provide a fixed lift multiplier. See the [U.S. Navy aerodynamics training guide's ground-effect section](https://www.cnatra.navy.mil/training/assets/media/aerodynamics/aero-trainee-guide.pdf).

At 75 m/s and 2,400 t, kinetic energy is 6.75 GJ. An ideal constant net deceleration of 0.15 g would require about 1.91 km of ground roll. This excludes airborne approach, flare, touchdown scatter, brake temperature, tire adhesion, runway slope, wind, failure margins and pavement strength. **It is not a runway-length recommendation.** Runway width, wing clearance, turning apron, hangar fit and gear loading may constrain the aircraft before length does.

## Explicitly unresolved

- Real-world lift distribution, stability derivatives, trim, control saturation, engine characteristics, fuel volume, range and structure.
- Native game aerodynamics at multi-million-kilogram mass, complex-physics islands, gear loads and AI turn behavior.
- Airborne separation and wake interaction. A clean visual release is insufficient; measure relative motion and contacts.
- Aerial recovery, nuclear heat/power management and water operation. Each is a separate concept branch.

The next useful evidence is a scale-and-route survey followed, under a later implementation request, by a simple native flight mule with measured mass, forces and controls. Detailed modeling should wait for those constraints.
