# G-240 BREAKWATER — original working concept

**Visual revision:** the [CL-1201-derived carrier asset brief](../Assets/ModelBriefs/BREAKWATER_CL1201_V2.md) supersedes this document's eight-pod/twin-boom shape. The gameplay role remains; the dimensions and engineering cases below are historical screening inputs, not revalidated geometry for the new art direction.

**Status:** preferred direction for further study, not an approved aircraft specification. The designation and name are provisional. The current 2055 direction is **fission**, following the user's correction from fusion. Read [SYSTEMS_2055.md](SYSTEMS_2055.md) and [2055 parameters](../Concepts/2055-study-parameters.json) for the flagship package. The older [conventional parameters](../Concepts/study-parameters.json) and [ENGINEERING.md](ENGINEERING.md) remain a separate comparison.

## The aircraft we want to see

An escort fighter approaches what first looks like a distant cloud bank. Eight large nacelles resolve around a broad, thick wing. The centerbody passes overhead; its cockpit windows are still human-size. Segmented surfaces adjust its enormous wing while a mission-bay door opens behind the main structure, releasing one small vehicle into clean air. The plane continues its slow turn while its escorts move outward to cover the operation.

Its job is to bring an invasion or reaction force, establish a foothold and sustain it until ordinary faction logistics can take over. The spectacle comes from seeing that operation happen at scale. The visual language should fit Nuclear Option's military aircraft: credible apertures, rational panel boundaries, understated paint, functional lights and a cockpit with native instruments.

## Three directions considered

| Direction | Study envelope, not sourced specifications | Strength | Principal cost / reason for position |
| --- | --- | --- | --- |
| **A — BREAKWATER, preferred** | 240 m span; 150 m length; 2,400 t mass ceiling to test; subsonic flight with the 2055 fission package. | A true megaplane with room for cargo, mission equipment and a limited deployable force. An-225-style transport logic, Roc-style integration lessons, spanloader wing depth and visibly advanced systems. | Far beyond demonstrated transport scale. Installed nuclear systems, structure, trim, airport compatibility and game-map fit remain gates. |
| **B — LOWTIDE** | Roughly 180–240 m span; exact mass unset; Pelican-inspired low maritime route. | An extraordinary sea-skimming silhouette and logistics role. | Ground-effect dependence, waves, obstacle avoidance and bank clearance would dominate the project. Native ground-effect support is unverified. Keep as an alternative, not an invisible bonus for A. |
| **C — SKYKEEP** | CL-1201-scale expansion; dimensions and mass deliberately unset. | A further increase in airborne-base scale beyond BREAKWATER. | The preferred aircraft now already studies fission; a larger base would amplify shielding, structure, cooling and recovery requirements. Preserve as an alternative scale, not an additional free capability. |

A is preferred because its impossible-looking size can be explained through wings, power, thrust, structure and restricted operations. The fission package makes it more ambitious while preserving explicit mass and energy accounting. Its feasibility remains unproven.

## Initial geometry and systems hypothesis

- A deep, wide centerbody integrated with a thick inner wing; modest sweep, large outboard lifting panels and twin fins on two aft booms.
- Eight nacelles remain the silhouette hypothesis: four inboard nuclear-heated powertrains and four outboard chemical auxiliary units. This is a layout proposal, not a measured engine design. Keep hot thermal routes relatively short.
- Protected plant and dense mission equipment near the center of lift, separately allocated chemical reserve, a forward flight deck at ordinary human scale, and deliberate crew/plant separation.
- Multiple main bogies beneath reinforced inner structure. Wheel count, tire loads, gear tracks and retraction are unresolved; the sketch must not be read as a landing-gear design.
- A lower aft mission bay reserved for a later release-clearance study. Do not cut across the primary wing carry-through structure. A docked aircraft is a payload with mass, aerodynamic interference and failure cases.
- Segmented control surfaces, fuel zones and engine groups create useful damage regions. A lost outer wing must not leave its engines, control surfaces or effects hanging in the original world position.

The [2055 systems sheet](../Concepts/2055-systems.svg) explores the current package. The [earlier sheet](../Concepts/megaplane-study.svg) remains the conventional silhouette reference. Neither defines wing area, thickness, collision geometry, aero sections, structural sizing, radiation shielding or a finished silhouette.

## Role and operating doctrine proposal

The adopted gameplay role is an **invasion / reaction-force flying carrier and support hub**. Infantry, aerial drones, ground drones, onboard artillery, AWACS, rearm and refuel all form its combined purpose. The detailed [role specification](GAMEPLAY_ROLE.md) defines the operation: prepare, arrive, deploy, capture, sustain, then hand over or recover.

The first future technical experiment remains an air-started native-flight mule. The gameplay default is an AI-flown shared faction asset with an authorized commander; optional player piloting follows validation. Full role acceptance requires a complete expedition loop, not just a flyable carrier. The [300 t manifest study](EMBARKED_FORCE.md) now reserves a finite force and supply stocks. Bays, release/recovery mechanisms, service interfaces and compatibility remain unverified; a walkable multiplayer interior is separate.

Mission payload and aircraft self-defense compete for mass, volume, power and cost. The protection architecture includes warning, EW/decoys, DIRCM, limited physical point defense, localized kinetic protection and damage tolerance. The offensive onboard artillery battery is separately budgeted mission equipment; it is not an orbital Support call or the same installation as point defense. Equipment performance, price, faction and acquisition rules remain unresolved. The carrier needs escorts and a real ground force.

## Art brief for a later modeling pass

1. Produce silhouette variants before committing to panel detail. Include a native fighter and a human datum at true scale.
2. Show plan, side, front and low three-quarter views; use a cutaway to reserve wing spars, fuel, cargo, gear wells and duct space.
3. Make wing depth and centerbody join feel load-bearing. Avoid a thin fighter wing enlarged around an enormous hollow hangar.
4. Use large purposeful forms and a few identifying features: deep wing shoulder, paired nacelles, split tail, aft bay. Surface detail reinforces these forms.
5. Break up large surfaces with service seams and controlled value changes. Use localized cockpit and service-area detail, tiling or reusable material treatment at distance; a single atlas cannot deliver uniform close-up density over this area.
6. Review healthy, operating and damaged views in the same lighting and from gameplay distances. Keep the cockpit readable and full human scale.

## Decisions still open

The user has requested research and concept files and selected fission for the advanced energy direction. Final silhouette, exact size, name, role, nuclear installation, launch mechanism, aircraft capacity, defense equipment, damage partition, runway requirement and faction remain open engineering/design decisions. This dossier supplies a direction and a way to reject bad assumptions before production.
