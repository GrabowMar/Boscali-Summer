# BREAKWATER 2055 — fission flagship systems concept

**Visual revision:** the [current CL-1201 carrier asset brief](../Assets/ModelBriefs/BREAKWATER_CL1201_V2.md) replaces the eight-nacelle/twin-boom art layout. This file retains the earlier energy-path and screening budgets; it does not validate the new geometry, engine installation or scale.

**Preferred setting direction:** a fission-powered technological marvel, following the user's correction from fusion. **Stage:** research and original concepts only. This extends the earlier conventional reference; it does not prove an aircraft can be built or flown.

Use [2055-study-parameters.json](../Concepts/2055-study-parameters.json) for this variant's assumptions. The older [study-parameters.json](../Concepts/study-parameters.json) remains a separate conventional comparison. Neither is loaded by the mod.

## The marvel

BREAKWATER is a flying strategic installation with a physically understandable energy source. A protected fission plant sits within its deep center-wing structure. Four inboard nuclear-heated turbine/fan powertrains provide the cruise propulsion hypothesis. Four outboard chemical auxiliary nacelles preserve the eight-pod silhouette while reducing the need to transport reactor heat across the entire span. The actual architecture and number of units remain open to engineering review.

An instrumented flexible wing manages loads through passive tailoring, measured deformation and segmented controls. Its mission systems combine a finite deployable force with a layered protection architecture. Crew spaces, maintenance routes, machinery and shielding are visible design commitments, not empty space around a glowing core.

The aircraft's extraordinary character comes from its coordinated systems: it is a rapid invasion / reaction-force carrier with infantry, aerial and ground drones, onboard artillery, AWACS and finite rearm/refuel capability. It sustains an expedition, observes its own structural condition, reduces loads after damage and preserves essential functions through isolation and redundancy. It remains dependent on escorts, consumables, cooling, maintenance and suitable operating space. See [GAMEPLAY_ROLE.md](GAMEPLAY_ROLE.md).

## Functional architecture

| System | Concept requirement | What must be reserved in the model |
| --- | --- | --- |
| Protected fission power island(s) | Provide controlled heat with appropriate shielding, containment, monitoring and support. Number of reactors is unresolved. | Inboard protected machinery volume, structural supports, crew/payload separation and remote service paths. |
| Indirect propulsion heat transfer | Deliver heat to engine airflow across an isolating boundary. | Short protected thermal routes, substantial exchanger housings, access and thermal expansion allowance. No reactor internals are specified. |
| Inboard nuclear-heated powertrains | Produce steady atmospheric thrust with real intake, cycle and exhaust behavior. | Four large inboard nacelles as an initial layout; fan/core proportions and temperature limits remain unmeasured. |
| Chemical assistance | Startup support, additional power where justified and a defined contingency envelope. | Four auxiliary nacelles and separately accounted fuel. Chemical-only recovery is a requirement to size, not a current capability. |
| Auxiliary generation | Supply essential aircraft equipment and finite mission demand. | Generator/conversion equipment, distribution, fault isolation and cooling. The electrical network does not power all cruise thrust in this branch. |
| Shutdown heat removal | Continue cooling after trip, loss of propulsion airflow and landing. | Protected independent energy/support provisions, monitoring and ground-service connections. |
| Wing management | Sense loads, reallocate controllable lift and reduce the permitted envelope after faults. | Segmented surfaces, local actuators, inspectable structure and sensing routes. Passive integrity remains necessary. |
| KINETIC VEIL, provisional protection name | Combine warning, EW/decoys, DIRCM, limited physical interception and localized protection. | Sensor windows, guarded optical apertures, finite magazines, service access and protected vital compartments. |
| Invasion force and service | Carry infantry, aerial/ground drones, shuttles, finite stores and ground support with explicit custody, mass and COM states. | Bays, handling/service channels and deployment equipment isolated from major structure, hot flow, defense and plant servicing. |
| Onboard artillery and AWACS | Provide real mounted fire support and native observed air tracks for the expedition. | Damageable mission equipment, sensor coverage, firing/handling clearance, ammunition and electrical/thermal demand. |
| Long-sortie crew and maintenance | Support operators and service the machine over a finite sortie. | Human-scale flight deck, rest/environmental provisions, inspection access and equipment handling routes. |

The linked [technology portfolio](../Research/05-2055-technologies.md) supplies the wider stack and its evidence limits. [Fission research](../Research/04-fission-propulsion.md) supports the energy-path choice; [protection research](../Research/06-defense-and-survivability.md) supports the defensive layers.

## Screening power balance — an invented case, not a selected plant

The original clean-airframe calculation gives about **369.3 MW useful thrust power** at 180 m/s. Geometry, mass ceiling and atmosphere are retained only to compare architectures. New nacelles, thermal equipment and protection will change the drag and mass problem.

| Mainline allocation / assumption | Screening value |
| --- | ---: |
| Total reactor thermal power | 1,500 MWth |
| Heat delivered to propulsive powertrains | 1,400 MWth |
| Overall delivered-heat-to-useful-thrust-power efficiency | 32%, assumed |
| Useful thrust power | 448 MW |
| Remaining propulsion energy assigned ideally to engine airflow / wake | 952 MW |
| Heat to separate auxiliary conversion | 100 MWth |
| Auxiliary gross electric efficiency | 40%, assumed |
| Auxiliary gross electricity | 40 MWe |
| Plant electrical auxiliaries | 10 MWe |
| Hotel and mission electrical allocation | 30 MWe |
| Auxiliary conversion rejection | 60 MW |
| Conservative onboard dissipation of electrical loads | 40 MW |
| Auxiliary/local heat sink before unbudgeted hot-system losses | 100 MW |

The ideal bookkeeping closes: **448 + 952 + 100 = 1,500 MW**. The 32% is already the overall efficiency from delivered propulsion heat to useful thrust power; do not multiply by another fan/propulsive efficiency.

Assigning all 952 MW to propulsor airflow assumes negligible heat leakage from hot transport, casings and other equipment. Actual losses, primary-system/structural heat loads, exchanger pressure loss and local cooling remain unresolved. Some electrical energy can leave as RF/light; counting it all as heat is a conservative simplification for this ledger.

448 MW corresponds to about 2.49 MN thrust at 180 m/s, approximately 21.3% above the old clean-airframe drag requirement at that speed. This is **a margin to spend in a future installed-performance model**, not established climb capability or final cruise closure. The original eight-engine 500 kN static placeholders do not carry over to these four nuclear-heated and four auxiliary units.

### Why full nuclear-electric propulsion is the comparison, not the default

For a separate all-electric case, 750 MWe gross minus 150 MWe plant demand gives 600 MWe net. At assumed 45% conversion that requires 1,666.7 MWth. Allocating 520 MWe to propulsion at 90% electrical-to-shaft and 80% shaft-to-useful efficiency yields 374.4 MW useful power.

Under the comparison assumptions, approximately 1,198.7 MW requires an onboard heat sink, 93.6 MW leaves as propulsive wake loss and 374.4 MW becomes useful thrust power. That electrical case barely exceeds the original clean-airframe requirement before added cooling drag. It also needs a different installed mass assessment.

Indirect airbreathing moves much of the energy path into engine airflow; it does not eliminate it. Do not combine the electric comparison's 600 MWe output, the mainline's 448 MW thrust power and the mainline's smaller accessory heat sink as if they belonged to one plant.

## Thermal solutions and their limits

- **Use propulsion airflow for the high-grade energy path.** This is the main architectural solution. It requires real engine/exchanger performance and may create a strong infrared signature.
- **Separate temperature levels.** Keep hot plant/propulsion equipment distinct from electronics, crew conditioning and any cryogenic equipment. Avoid pretending all heat can use an ambient-temperature coolant loop.
- **Reserve accessory heat exchangers and airflow.** Even the ideal 100 MW accessory sink is large; actual hot-system leakage adds to it. Duct volume, pressure loss, drag, hot-day limits and fouling must be modeled.
- **Use temporary storage only for transients.** At 100 MW, one minute corresponds to 6 GJ. Stored heat must later be rejected; a buffer is not an endurance solution.
- **Provide a post-trip and stationary mode.** The fission source, stored heat and decay heat require different time histories. Removing thrust or reaching the ground cannot remove the cooling requirement.

Radiating heat from the wing is not a complete answer. As an idealized illustration, emissivity 0.85, a 600 K surface and a 250 K radiative background give roughly 6.06 kW/m² net flux under `epsilon sigma (T^4 - Tbackground^4)`, using the simplified radiation relation in [NASA's Passive Thermal Control Engineering Guidebook](https://ntrs.nasa.gov/api/citations/20220006584/downloads/NASAPassiveThermalGuidebookv5%201Public.pdf). Both faces of a 7,200 m² wing would radiate about 87 MW if fully exposed and uniformly that hot. This ignores atmospheric/solar/view-factor effects and exceeds appropriate temperatures for many aircraft components. It is not a design recommendation. The all-electric comparison's heat would require about 198,000 m² under those idealized assumptions.

## Mass ledger — allowances, not sized equipment

| Allocation | Mass |
| --- | ---: |
| Structure and flight controls | 600 t |
| Reactor, shielding and containment | 500 t |
| Propulsion powertrains and nacelles | 230 t |
| Electrical / thermal utilities and distribution | 140 t |
| Crew spaces, avionics and life support | 80 t |
| Localized passive protection | 80 t |
| Defensive and warning equipment | 50 t |
| Chemical reserve fuel | 250 t |
| Mission payload, detailed in [EMBARKED_FORCE.md](EMBARKED_FORCE.md) | 300 t |
| Unallocated growth reserve | 170 t |
| **Total mass ceiling to test** | **2,400 t** |

Reactor and shielding mass are not derived from a radiation or thermal design. Propulsion and utilities include their own equipment and supporting systems; a later itemized ledger must eliminate overlaps and omissions. Growth reserve is not spare installed equipment or extra payload.

The former 700 t fuel budget has not become free cargo capacity. Plant, protection, distribution, cooling and reserve fuel consume the new allocation. Radiation protection and installed plant mass may force the aircraft to become larger, carry less or abandon this architecture. No protection mass establishes an armor rating.

The invasion-role study subdivides the existing 300 t mission line; it does not add mass to this ledger. Its 70 t transferable fuel is separate from the 250 t carrier chemical reserve. Artillery hardware and AWACS mission equipment are included in that mission breakdown, while baseline flight avionics and defensive equipment remain in their original lines. Volume, service tracks, power/cooling and weapon/deployment clearance still require a complete installation study.

## Failure behavior that makes the marvel believable

| Condition | Required concept behavior, not implemented |
| --- | --- |
| Reactor trip | Main power reduces; residual heat remains. Preserve essential cooling/control and transition only within a demonstrated contingency envelope. |
| Thermal train or heat exchanger lost | Isolate the affected capability, reduce output and abort relevant mission operations. Do not automatically regain its thrust elsewhere. |
| Chemical reserve depleted | Restrict operations that depend on it; nuclear endurance does not restore a depleted chemical reserve. |
| Accessory cooling degraded | Shed optional mission demand and derate; defensive systems compete for remaining capacity. |
| Sensor or defense layer lost | Show reduced coverage/capability. Other layers do not become universally effective. |
| Outer wing or control group damaged | Recalculate the permitted maneuver envelope from remaining physical authority; severe loss can remain unsurvivable. |
| Stationary after landing | Use a separately engineered cooling/support mode. Landing is not thermal shutdown. |

## Visual direction and next evidence

The updated systems sheet should show the deep wing, inboard plant region, short thermal connections, grouped propulsion, accessory cooling, protected crew spaces, defensive apertures and isolated mission bay. Equipment routing is schematic; it is not a reactor, piping or weapon blueprint.

Before detailed production, close installed propulsion/cooling performance, radiation and shutdown requirements, structural layout and airfield/route fit. Then produce a native game physics mule under a separate implementation request. The marvel is the target; these are the engineering questions that can make its design coherent.
