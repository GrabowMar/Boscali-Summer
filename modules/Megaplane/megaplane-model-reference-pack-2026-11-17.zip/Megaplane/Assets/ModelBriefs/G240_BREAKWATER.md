# G-240 BREAKWATER — model description

**Reference images removed:** visual descriptions below are historical text, not a retained image set.

**SUPERSEDED VISUAL DIRECTION.** Retained as history. Use [BREAKWATER_CL1201_V2.md](BREAKWATER_CL1201_V2.md); its crescent-wing/single-fin/four-dorsal-engine design replaces this file's eight-pod/twin-boom requirements.

**Purpose:** main invasion / reaction-force carrier. Preserve [GAMEPLAY_ROLE.md](../../Design/GAMEPLAY_ROLE.md) and the fission architecture in [SYSTEMS_2055.md](../../Design/SYSTEMS_2055.md). These images and descriptions are art inputs, not production geometry or engineering validation.

## Copyable model-generation description

An enormous grounded near-future military flying carrier with one deep central transport fuselage blended into a broad, thick, moderately swept wing. The overall study envelope is 240 m wingspan, 150 m nose-to-tail length and roughly 32 m overall height. Preserve the 1.6:1 span/length plan ratio. A small forward flight deck has ordinary human-size windows and access doors; its glazing must not scale into a giant passenger-liner bridge.

Exactly eight attached forward-facing propulsion pods: two large inboard indirect nuclear-heated turbine/fan pods per side and two smaller chemical auxiliary pods per side farther outboard. The large pods have substantial service/exchanger fairings, normal fan intakes and turbine-style exhausts. Keep the fission installation enclosed inside the center-wing region. Two narrow aft structural booms flank the central rear mission body. Each boom carries one vertical fin; one horizontal tailplane connects the two fins. Do not add a center fin, second occupied fuselage or naval flight deck.

Two smooth elongated conformal AWACS fairings sit on the dorsal shoulders. Small optical/navigation/point-defense apertures are subordinate details. A pair of compact ventrolateral artillery housings have restrained external barrels and protective fairings. The lower aft centerbody has a framed, segmented-door mission bay, clear of the main structural carry-through and hot propulsion equipment. Two separate retractable external service stations occupy reserved lower-aft shoulder positions. Numerous heavy retractable bogies attach beneath the centerbody and inner wing, with separate doors and struts; exact group/wheel counts are unresolved.

Use subdued light service-gray painted metal/composite, charcoal anti-glare and dielectric areas, dark machinery recesses, large readable panel groups and localized service wear. Deep structural forms and tiny human-scale interfaces communicate size. Avoid neon, exposed power cores, force fields, decorative guns, excessive armor scales and franchise insignia.

Generate the basic airframe in a closed, neutral state: gear retracted, bays shut, service equipment stowed and control surfaces neutral. Keep all payload craft separate from the carrier mesh. Reconstruct moving/detaching parts as independent objects rather than accepting one fused AI mesh.

## Reference authority

| Input | Use |
| --- | --- |
| 01 carrier primary (image removed) | Master appearance, material language and three-quarter massing. |
| 02 corrected plan study (image removed) | Top-layout/proportion aid; visually near the intended 1.6 ratio, not a measured blueprint. |
| 03 port study (image removed) | Side profile and root depth; generated view remains oblique. |
| 04 front study (image removed) | Symmetry and nacelle-count aid; camera remains somewhat elevated. |
| 05 operational view (image removed) | Art direction for open bay, extended gear, service equipment and external artillery housings. It is a different pose and not a calibrated underside drawing. |

The corrected top study required proportion iterations. Drafts are explicitly excluded from shape authority. Build a measured blockout from the text envelope, then reconcile the selected images; do not stretch one image into a claim of exact matching views.

## Main forms and reserved volumes

- **Crew/nose:** distinct human-scale flight deck and crew access; reserve pilot/seat/camera space at 1:1 scale. External windows are not a cockpit interior design.
- **Center-wing structure:** deep continuous load-bearing volume around protected machinery and attachment paths. The colored plant block in the systems diagram is an annotation, not an exposed exterior object.
- **Wing panels:** substantial inner thickness transitioning to thinner outboard panels. Segment control surfaces without cutting away every load path.
- **Propulsion:** four large and four small nacelle instances, each with a real pylon and its own parent wing assembly. Exact nacelle dimensions and cycle hardware remain unset.
- **Tail:** two booms, two fins, one connecting tailplane. Leave an aft/lower mission path between the booms; tail loads and opening clearances still need study.
- **Bays:** model door thickness, frame, hinge/pivot and a simple useful internal liner. The operational image suggests a doorway; it does not prove that either shuttle or all twelve UAVs fit.
- **Service equipment:** reserve two spatially separated stations and access. Platforms in the operational image are exterior handling concepts, not validated SKYWELL mechanisms or receiver interfaces.
- **Gear:** grouped retractable multi-axle assemblies with service space and door boundaries. The image's tire count is not a load-bearing solution for 2,400 t.
- **Mission systems:** keep AWACS, onboard artillery, self-defense and cargo handling visually distinguishable. Artillery/point-defense modeling here is exterior-only.

## Separable art assemblies

| Assembly | Separate pieces / intended motion |
| --- | --- |
| Centerbody | Cockpit shell, center structural shell, aft mission shell; full interior is separate scope. |
| Wings | Left/right inner, middle and outer art sections; individual flap/aileron surfaces. |
| Eight propulsion units | Pylon, nacelle, visible fan/hub elements, optional access closures; each follows its supporting wing. |
| Tail | Two booms, fins, rudders, connecting tailplane and elevator surfaces. |
| Gear | Retraction frames, struts, suspension elements, bogies, wheels and doors with distinct pivots. |
| Mission bay | Door leaves, hinges, liner, handling floor/rails, restraints and optional lift/cradle. |
| Service stations | Stowed housing, deployment linkage and interface/handling head as separate objects. |
| Sensor/defense installations | Fixed fairings, apertures and any moving exterior heads; no internal weapon/reactor mechanisms. |

This object list does not require one physics rigidbody or native damage part per mesh. Later runtime design determines the native partition and bounded collider/renderer budgets.

## Required measured checks before a mesh is accepted

1. Span, length, height, symmetry and datum; positive unit scale and correct axes.
2. Exactly four large and four small propulsion pods and the same two-boom tail in every view.
3. Continuous wing/centerbody structure around bay openings; actual payload/service swept envelopes.
4. Human-scale crew landmarks, wheel ground contact and measured gear-door motion.
5. Explicit pivots, anchors, component parenting, LOD ownership and simple collision surrogates.
6. Neutral-light, matcap, wire and near/distant silhouette review, followed by export/reimport and loaded Unity readback later.

No present image validates those checks or establishes real-world airworthiness.
