# LANTERN — modular aerial UAV

**Reference images removed:** visual descriptions below are historical text, not a retained image set.

**OUTSIDE CURRENT HANDOFF:** supporting assets are excluded from the user's big-plane-only CL-1201 revision. Retained as history.

**Working art name.** Primary generated recon reference (image removed). This is a reusable aircraft concept for the carrier's finite aerial wing, not a claim that existing missile-based Vanguard flights already support recovery.

## Copyable model-generation description

An original pilotless fixed-wing support UAV with a slender central fuselage, gently swept high shoulder wing, two slim tail booms and exactly one exposed aft pusher propeller behind the center fuselage between the booms. Two small vertical fins and one connecting horizontal tail sit aft of the propeller. Keep a clear air gap between the propeller's swept disc and the tail structure. There is no cockpit glazing, no lift rotor and no ducted-fan ring.

A shallow removable belly reconnaissance module has one small protected observation aperture. Dark side panels are service/dielectric panels rather than pilot windows. A top maintenance cover and discrete cradle/service pads sit near the centerbody. The baseline reference has a simple extended tricycle gear arrangement and a stationary, sharply modeled propeller.

Use subdued aircraft-gray painted surfaces, charcoal equipment panels, dark rubber, restrained seams and small handled-edge wear. Prioritize clean wing/boom separation and a legible modular payload interface. No exposed weapons in the reconnaissance configuration, no fantasy winglets or decorative machine detail. The complete craft is separate from its carrier and payload module.

## Provisional visual envelope and variants

- Approximately **6 m long and 9 m span** as visual targets; gear/propeller height is to be measured during blockout.
- Reconnaissance: the generated shallow observation module.
- Combat support: a separately described closed mission module on the same centerbody interface; no image or weapon engineering is supplied for this variant.
- Utility/reserve: same airframe and service geometry, with the actual supported mission payload to be selected later.

The mission allowance of 24 t for twelve loaded UAVs does not prove a 2 t finished aircraft or a working recovery system. Propulsion, stability, payload mass, module drag, storage and service interfaces remain open.

## Separate objects and checks

Keep fuselage, two wings, control surfaces, two tail booms, fins/rudders, connecting tail/elevator, propeller/hub, gear and belly module separate where motion or replacement requires it. Add measured cradle/service attachment empties without treating visible lifting loops as a solved capture mechanism.

Verify propeller clearance through full motion, ground clearance, correct boom symmetry, gear placement, module installation/removal and sensor sight lines. Use a separate later blur mesh; preserve stationary blades for modeling. Do not fuse the belly module, wheels or propeller into the main hull.

This single three-quarter reference does not define hidden structure, true orthographic dimensions, gear retraction, internal machinery or a flight model. A clean recon mesh can supply a useful blockout, but it needs retopology, pivots, UV/materials, collision and metric reconstruction before game integration.
