# HARBOUR — insertion / recovery shuttle

**Reference images removed:** visual descriptions below are historical text, not a retained image set.

**OUTSIDE CURRENT HANDOFF:** supporting assets are excluded from the user's big-plane-only CL-1201 revision. Retained as history.

**Working art name.** Primary generated reference (image removed). The shuttle supports troop/UGV delivery and survivor pickup in the [invasion role](../../Design/GAMEPLAY_ROLE.md). It is an original future asset, not an existing Skylark replacement or proven carrier-compatible aircraft.

## Copyable model-generation description

A compact military tiltrotor cargo shuttle with a tall rectangular rear-ramp fuselage, rounded structural chamfers, high shoulder wing and a raised ordinary two-seat cockpit. Exactly two open tilting proprotors are mounted at the wingtips, one per side; each has a clear transverse nacelle pivot. The baseline reference shows vertical-lift nacelle orientation with sharp stationary horizontal rotor blades. No ducts and no four-fan arrangement.

The baseline operating assumption is autonomous/supervised flight. The two-seat flight deck preserves an optional future crewed configuration; it does not create extra personnel. A crewed variant must assign its pilots explicitly in the crew roster/mass ledger rather than adding uncounted crew or silently consuming the 128 infantry allocation.

A single vertical tail and high horizontal stabilizer leave a distinct rear loading opening. The broad rear ramp is shut in the primary image. Robust extended landing gear supports the cargo body, with separate main struts/wheels and a nose unit. Include a small crew door, practical steps, cargo tie-down fittings, accessible machinery covers and restrained navigation lights. There is no armament in the baseline model.

Use the carrier family's light service-gray paint, darker machinery/access panels, dark glazing/rubber and cause-based wear. The cargo body, loading route and two large rotors must dominate the silhouette. Keep cockpit and access details at human scale. Render/model the shuttle alone; troops, containers and ground drones are separate payload objects.

## Provisional visual envelope

| Item | Visual study target |
| --- | --- |
| Length | About 12 m |
| Cargo body exterior width | About 3.2 m |
| Wingtip proprotor-center spacing | About 14 m |
| Rotor diameter study | About 6 m, giving roughly 20 m lateral swept envelope |
| Height | About 4.2 m, subject to gear/rotor configuration |
| Payload idea | Eight to sixteen troops **or** a small ground vehicle, subject to measured fit/mass/control analysis |

These dimensions are new art assumptions. The 20 t mission allocation for two shuttles is a mass allowance, not evidence that this envelope or payload can be built at that mass. Interior dimensions, floor loading, seating, ramp clearance and carrier-bay fit remain unresolved. Do not silently shrink troops or UGVs to fit.

## Separate objects and pivots

- Fuselage shell, cockpit glazing, simple cargo liner and removable seating/cargo fittings.
- Left/right fixed wing, flap/control surfaces, two nacelle tilt assemblies and two independent propellers/hubs.
- Tail fin/rudder and horizontal stabilizer/elevator.
- Rear ramp, side access door, gear doors, retraction frames, suspension and independently rotating wheels.
- Native-interface placeholder empties for pilot/seat/camera, cargo exit/restraints, sensor and service points; measure later.

Use the blade axis for propeller spin and a separate transverse hinge for nacelle tilt. Verify blade swept volumes, ground clearance, tail/fuselage clearance, ramp access and both tilt extremes before accepting a moving model. A rotor blur mesh is a separate later asset; do not generate blurred blades into the source mesh.

## Variants and limits

Troop and cargo configurations share the same exterior chassis and use separate interior fittings. Folding blades/wing, autonomous recovery and carrier docking are not assumed solutions to storage or flight. The reference has not established forward nacelle pose, rear-ramp geometry, hidden wheel arrangement or a complete cockpit. Those require additional measured reconstruction/views later.
