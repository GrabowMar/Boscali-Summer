# MULE — modular ground drone

**Reference images removed:** visual descriptions below are historical text, not a retained image set.

**OUTSIDE CURRENT HANDOFF:** supporting assets are excluded from the user's big-plane-only CL-1201 revision. Retained as history.

**Working art name.** Primary generated logistics reference (image removed). This is a visual chassis concept for the embarked ground fleet, not a replacement for or measured fit to the native Hexhound vehicle.

## Copyable model-generation description

A low autonomous six-wheel utility vehicle with one central equipment tub, a short sloped nose, simple fenders and a guarded rear module bed. Exactly three substantial rubber wheels on each side, six total, with separate visible suspension arms. No driver's cab, windshield, tracks or humanoid body. The front has small recessed navigation optics and sturdy recovery eyes. Large practical side service covers and one guarded charging/fuel/service panel are accessible without removing the whole body.

The baseline logistics configuration has a low removable rear cargo rack carrying one closed rectangular supply container secured by visible corner clamps. Keep the rack, container and locks separate from the common hull. Use the same light military gray/charcoal family as the carrier, rugged dark tires and restrained wear around corners, fittings and access covers. The model should look like a maintainable load-carrying vehicle, not a miniature tank covered with decorative armor.

## Provisional visual envelope and variants

| Item | Visual target |
| --- | --- |
| Length | About 3 m |
| Width | About 1.8 m |
| Hull / baseline module height | About 1.25 m, to reconcile against wheel and cargo geometry |
| Common layout | Six-wheel chassis, low front equipment bay and rear removable module interface |

Reconnaissance substitutes a compact folding sensor-mast module; fire support substitutes an external support module; logistics uses the generated rack/container. All retain the same hull, wheelbase and module attachment area. Only the logistics image has been generated; other variants are descriptions rather than delivered reference images.

The 16 t allowance for eight loaded vehicles is a mission budget, not a verified 2 t vehicle design. Ground clearance, suspension travel, slope capability, cargo mass, energy source and fit through shuttle/carrier openings remain unmeasured. Keep the powertrain unspecified at this art stage.

## Separate objects and checks

- Hull and access covers; optics behind small protected windows.
- Six wheels with distinct spin axes, suspension arms and any steering pivots.
- Fenders as appropriate to motion/damage; avoid locking wheels inside intersecting bodywork.
- Cargo rack, container, corner locks and recovery fittings.
- Future mast/module hinge or traverse geometry only if that variant is developed; no weapon internals in this brief.

Verify six-wheel count from a reconstructed top/side layout, natural occlusion in the reference, tire clearance at full suspension/steering travel, underbody clearance and cargo-module removal. Keep containers as separate assets and track their gameplay quantity separately from the vehicle mesh.

One generated image does not establish the far-side geometry, physical drivetrain, usable suspension, collision shape or native ground-vehicle behavior. Use it as appearance input, then produce a measured chassis and appropriate simple colliders.
