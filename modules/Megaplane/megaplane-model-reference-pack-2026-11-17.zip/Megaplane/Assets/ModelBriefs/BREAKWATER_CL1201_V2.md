# BREAKWATER — CL-1201-derived carrier, visual revision 2

**Current scope: big plane only.** This written brief replaces the previous eight-pod/twin-boom visual direction. All generated reference images have been removed at the user's request. No supporting craft models or references belong to this handoff.

## Visual source

The user selected the [Lockheed CL-1201 article](https://en.wikipedia.org/wiki/Lockheed_CL-1201). Its [schematic](https://commons.wikimedia.org/wiki/File:CL-1201_Schematics.png) reproduces [NASA TM X-2386, Figure 4](https://ntrs.nasa.gov/api/citations/19710028801/downloads/19710028801.pdf), printed page 4. That drawing is the shape reference, not the previous generated plane.

The key source features are the crescent wing, low central nose/body, one large vertical fin without a horizontal tailplane, and four main engines clustered dorsally near the rear. The source plan has its nose pointing down. These features were visually checked against the actual drawing.

## Copyable model-generation description

A colossal CL-1201-derived military invasion-support aircraft, recognizable first by its enormous crescent wing and low elongated teardrop centerbody. The wing's deeply swept inner shoulders curve smoothly out of the forward/middle body; sweep reduces toward extremely long, slender tapered outer panels with rounded tips. Preserve the source-like approximately 2:1 wingspan-to-length plan envelope. Avoid a compact triangular delta, straight transport wing, raised bridge, twin fuselages or conventional tail booms.

Exactly one very large swept central vertical fin rises from the rear centerline. There is no separate horizontal tailplane. Exactly four massive nuclear-heated airbreathing main engine housings sit in a tight dorsal aft cluster, two per side of the fin. They have forward fan intakes, rear turbine-style exhausts and sturdy service saddles. No main engine pods hang beneath the outer wings. The fission installation is enclosed; its internal geometry is not part of this model reference.

Keep the nose long, low and rounded, with tiny ordinary-human-size cockpit glazing and restrained access details. Broad structural surfaces and wing-root depth should communicate a vast inhabited aircraft rather than an enlarged fighter. Segmented trailing-edge controls, a fin rudder, large service panels and flush inspection/lift-assist cover details reinforce its machinery without overwhelming the silhouette.

Add the invasion-support functions as restrained original exterior details: flush conformal AWACS panels on the broad upper/side shoulders, a few small protected optical heads, two compact ventrolateral mission-artillery housings, framed lower-aft mission-bay door seams and two flush stowed service-interface hatches. These are original adaptations, not claims about the historical drawing. Show no other aircraft, vehicles or personnel as part of the carrier mesh. There is no exposed reactor, naval flight deck or force-field surface.

Use pale matte military-gray painted metal/composite with charcoal dielectric and anti-glare areas, dark intake interiors, subtle panel-value changes and limited service/exhaust staining. Preserve large clean forms and human-scale details. Baseline pose: gear retracted, doors closed, service equipment stowed and controls neutral. Reconstruct the form from this written description and the explicitly consulted source drawing; separate all moving parts and verify hidden geometry during modeling.

## Proportions and scale

The new visual study follows the source's roughly **340 m span / 170.7 m length** proportion. Those values identify the reference envelope; they are not a newly validated aircraft specification. Final game scale is unresolved.

The earlier 240 × 150 m geometry, 2,400 t mass ledger and power/drag calculations remain historical screening cases. They must be recalculated for any adopted new geometry; the new images do not make those numbers true. At a retained 240 m span, a source-like ratio would imply roughly 120 m length, not 150 m. Do not mix incompatible dimensions while claiming fidelity.

## Reference-image status

All generated views and the local source-image copy were removed at the user's request. No generated image is approved or retained as geometry authority. External source URLs and historical generation prompts remain for provenance only.

## Required model separation

- Central body and continuous inner-wing structure; retain material around all bay openings.
- Left/right crescent wing sections and segmented control surfaces.
- One fin and separate rudder; no horizontal tail or twin-boom assembly.
- Four separate dorsal nacelles/service saddles and appropriate visible fan/hub geometry.
- Independent gear/door assemblies, bay-door leaves, service closures and any selected deployment mechanisms. The retracted references do not define the gear solution.
- Conformal sensor surfaces, small optical heads and external mission housings as maintainable art components. No reactor or weapon internals.

Art objects do not automatically define native rigidbodies or damage parts. Metric reconstruction, hinges, cargo/service clearance, cockpit interior, gear loads, LODs, colliders, materials and export/readback remain future production work. Existing module gameplay requirements remain relevant, but old visual constraints do not override this revision.
