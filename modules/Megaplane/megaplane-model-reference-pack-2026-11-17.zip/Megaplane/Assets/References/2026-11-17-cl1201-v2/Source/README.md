# External source provenance

The local schematic image was removed with all reference images at the user's request. These external source links and attribution remain as research provenance.

- [User-selected Lockheed CL-1201 article](https://en.wikipedia.org/wiki/Lockheed_CL-1201)
- [Schematic provenance on Wikimedia Commons](https://commons.wikimedia.org/wiki/File:CL-1201_Schematics.png)
- [NASA TM X-2386 report](https://ntrs.nasa.gov/api/citations/19710028801/downloads/19710028801.pdf)
- [NASA catalogue](https://ntrs.nasa.gov/citations/19710028801)

The drawing is Figure 4, printed page 4, of the November 1971 report. Commons identifies NASA authorship and public-domain status in the United States. No local image copy is retained in this reference directory.
