# CL-1201 carrier — written reference history

**All local images in this reference set were removed at the user's request**, including the source schematic copy. No generated view is approved or available here. The written big-plane description and external source provenance remain.

- [Carrier model description](../../ModelBriefs/BREAKWATER_CL1201_V2.md)
- [Plain model-description text](../../ModelBriefs/BREAKWATER_CL1201_V2.txt)
- [Modeling handoff](../../MODELING_HANDOFF.md)
- [External source provenance](Source/README.md)
- [Removal manifest and historical metadata](manifest.json)

## Historical generation prompts

These record rejected image-generation attempts; they are not instructions to generate new images.

- [Primary-view prompt](Prompts/01-carrier-primary.txt)
- [Plan-view prompt](Prompts/02-carrier-plan-study.txt)
- [Port-view prompt](Prompts/03-carrier-port-study.txt)
- [Front-view prompt](Prompts/04-carrier-front-study.txt)
- [Underside-view prompt](Prompts/05-carrier-underside-study.txt)

No mesh, calibrated projection or gameplay implementation is supplied.
