# Superseded reference-generation history

**All images from this set and its Drafts directory were removed at the user's request.** Only historical prompts and metadata remain. No generated image from this set is approved or retained here.

The current big-plane-only written direction is [the CL-1201 carrier brief](../../ModelBriefs/BREAKWATER_CL1201_V2.md). Supporting-craft descriptions are outside the current handoff.

- [Historical prompts](Prompts/)
- [Draft-attempt prompts](Drafts/Prompts/)
- [Removal manifest and historical metadata](manifest.json)
