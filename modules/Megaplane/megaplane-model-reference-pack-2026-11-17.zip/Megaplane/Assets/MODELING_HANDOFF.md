# Big-plane image-to-3D handoff — CL-1201 V2

This handoff retains written model descriptions and source provenance. All local reference images were removed at the user's request. No approved generated image or mesh is supplied.

Current scope is one carrier only. [BREAKWATER_CL1201_V2.md](ModelBriefs/BREAKWATER_CL1201_V2.md) defines the written visual direction; the [reference history](References/2026-11-17-cl1201-v2/README.md) retains prompts and source URLs only. The former eight-pod/twin-boom geometry and all supporting-model references are superseded/outside this handoff.

## Input priority

1. The role/system requirements and model brief define required function, count and dimension targets.
2. The external CL-1201 source drawing and written brief guide proportions: approximately 2:1 span/length. The source envelope is about 340 × 170.7 m; choose final game scale explicitly rather than combining that ratio with the old 240 × 150 m case.
3. Reconstruct massing and materials from the written brief and explicitly consulted external sources; no rejected generated view is geometry authority.
4. Define rest poses and open/deployed mechanisms explicitly during modeling; no retained reference images establish them.

Only carrier geometry is supplied. Reserve useful cargo/service volume without modeling, scaling or fusing supporting craft into the carrier mesh. A closed bay seam does not establish mission payload fit.

## Common metric contract

- Author in **metres**. Blender: nose +Y, up +Z, starboard +X. Canonical Unity: nose +Z, up +Y, starboard +X.
- Use a fixed documented airframe/chassis datum. Loaded COM is separate and varies with inventory; do not make the model datum a claim of physical balance.
- Apply positive unit scale. Mirror real geometry and check winding; avoid negative object scales.
- Give hinges, tilt joints, wheels, rotors, suspension and deployment mechanisms separate origins on their actual axes. Keep component-local frames through export.
- Reserve attachment empties for later measured cameras/pilots, gear, propulsion, sensors, cargo exits, restraints, cradles and service interfaces. A label in a PNG is not a Unity transform.
- Keep people, scale proxies, preview cargo and other reference objects out of production exports.

## Reconstruction stages

**Blockout:** establish overall envelope, crescent silhouette, symmetry, low centerbody, wing-root depth and human-size access. Inspect multiple views before detail. Exactly four dorsal aft main engines and one central vertical fin are locked for this visual revision. There are no tail booms or separate horizontal stabilizer.

**Mechanical:** separate assemblies, reserve cargo/service swept volumes and test both extremes of every motion. Validate rotor/propeller discs, gear/door travel, cargo ramps, module removal and sensor clearance. Do not hide interpenetration behind a closed beauty pose.

**Surface:** rebuild stretched/fused AI geometry, maintain planar surfaces, use controlled bevels, and inspect matcap/reflections/wire. Intake holes, thin fins, wheel gaps and underside surfaces commonly need reconstruction. Large pixel-painted seams are not structural cuts.

**Materials/UV:** assign deliberate material roles and controlled texel density. Local cockpit/service detail and reusable large-surface treatment are more useful than forcing the entire giant aircraft into one uniformly detailed atlas. Preserve healthy/damaged texture compatibility and native material packing later.

**Game assembly:** art objects are not automatically native physics/damage parts. Design bounded damage/collider/LOD ownership separately. Detached art must follow its supporting assembly; moving pieces must remain available at appropriate LODs. Collision uses simple authored surrogates rather than the detailed render mesh.

**Export/readback:** follow the inspected Skylark path: direct FBX export with `axis_forward='-Z'`, `axis_up='Y'`, `apply_scale_options='FBX_SCALE_NONE'`, `bake_space_transform=False`; then measure a round trip. Inspect the normalized metric Unity asset and loaded bundle rather than trusting export flags alone. Recheck the installed tool versions before future production.

## Deliverables required from a later model pass

Editable source; part/material inventory; measured dimensions; rest-state/pivot/anchor manifest; near/LOD meshes; separate collision surrogates; UV/PBR maps and their packing; mechanical-sweep reports; inspected multi-view renders; FBX round-trip and loaded-asset evidence. Set numeric triangle, renderer, texture and collider budgets after blockout/native census rather than inheriting generic prop limits.

The references contain no reactor or weapon engineering. The protected plant is a reserved volume, and weapons are exterior art installations. None of the references or a subsequent mesh can validate reactor operation, armor performance, payload capacity, native flight, multiplayer or frame-time cost.
