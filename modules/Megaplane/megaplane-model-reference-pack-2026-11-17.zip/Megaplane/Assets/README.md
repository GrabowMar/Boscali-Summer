# Big-plane model description — CL-1201 direction

**Reference images removed at the user's request.** No local asset-reference images remain in this handoff. Written descriptions, research, source URLs and exact historical generation prompts are retained.

Current scope remains the big plane only. The written direction uses a CL-1201-derived crescent wing, one central fin and four dorsal main engines. Final scale and engineering remain unresolved.

- [Carrier model brief](ModelBriefs/BREAKWATER_CL1201_V2.md)
- [Plain model-description text](ModelBriefs/BREAKWATER_CL1201_V2.txt)
- [Modeling handoff](MODELING_HANDOFF.md)
- [Source URLs and retained prompt history](References/2026-11-17-cl1201-v2/README.md)
- [Text-only reference manifest](References/2026-11-17-cl1201-v2/manifest.json)

The older generated set, its drafts and the locally downloaded source schematic were removed from References. The ZIP exports no longer contain reference-image copies. There is no approved generated image or finished mesh.

Supporting-craft descriptions remain historical material outside the current big-plane-only handoff. No new images or supporting models were created during this cleanup.
