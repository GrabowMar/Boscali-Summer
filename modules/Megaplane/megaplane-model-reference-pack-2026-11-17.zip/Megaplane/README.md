# Megaplane — research and concept module

**Stage:** preproduction only. **Research date:** 2026-11-17. **Setting target:** approximately 2055. **Working concept:** G-240 BREAKWATER (provisional name).

A rapid invasion / reaction-force **flying carrier and support hub**: bring infantry and aerial/ground drones, establish a foothold, support it with onboard artillery and AWACS, and sustain it through finite rearm/refuel stocks. The preferred 2055 study combines that role with fission-heated airbreathing propulsion, an actively managed giant wing and layered protection. The earlier conventional aircraft remains a separate comparison case.

This directory is a development dossier, not a registered gameplay module. There is no C# implementation, aircraft prefab, flight model, bundle, purchase entry, or spawn hook. All proposed dimensions, systems, roles and budgets remain design hypotheses.

## Start with its job

[Gameplay role](Design/GAMEPLAY_ROLE.md) · [Embarked force and logistics](Design/EMBARKED_FORCE.md) · [Current integration audit](Research/07-gameplay-integration.md)

**Bring a force, establish a foothold, keep it fighting, and recover the survivors.** All required functions belong to the same aircraft. The first balance fixture fits 128 infantry, twelve aerial drones, two shuttles, eight ground drones, artillery/AWACS mission equipment, 70 t transferable fuel and finite ammunition/support stocks into the existing 300 t mission allowance. These are unvalidated design allocations, not measured assets.

[Invasion-cycle sheet](Concepts/invasion-cycle.svg) · [PNG preview](Concepts/invasion-cycle.png) · [Role study data](Concepts/invasion-role-parameters.json)

## Model-generation handoff

[Written big-plane CL-1201 model description](Assets/README.md) replace the previous mixed-model set. The new visual direction uses the source's crescent wing, single central fin and four dorsal main engines. Earlier system diagrams and 240 × 150 m calculations are historical studies, not the current visual authority. All local asset-reference images were removed at the user's request. Written briefs, prompts and research remain; no generated reference image is approved.

## Read in this order

1. [Real aircraft research](Research/01-real-aircraft.md): CL-1201, Pelican, Roc and An-225; proposed versus demonstrated capability.
2. [Fictional aircraft research](Research/02-fictional-aircraft.md): visual and encounter lessons, with official reference links.
3. [Nuclear Option pipeline](Research/03-nuclear-option-pipeline.md): current Skylark implementation, skills and integration constraints.
4. [Fission propulsion research](Research/04-fission-propulsion.md): historical evidence, indirect nuclear airbreathing and the electric alternative.
5. [2055 technology portfolio](Research/05-2055-technologies.md): materials, sensing, active load control, power, thermal management and maintenance.
6. [Point defense and survivability](Research/06-defense-and-survivability.md): realistic meanings of kinetic protection, demonstrations and limitations.
7. [Concept brief](Design/CONCEPT.md) and [2055 systems concept](Design/SYSTEMS_2055.md): preferred aircraft, mass/power ledgers and failure behavior.
8. [Engineering notebook](Design/ENGINEERING.md): the original conventional comparison and first-order sizing.
9. [Development gates](Design/DEVELOPMENT_GATES.md): questions to settle before artwork and implementation.

[2055 systems sheet](Concepts/2055-systems.svg) · [2055 PNG preview](Concepts/2055-systems.png) · [2055 study parameters](Concepts/2055-study-parameters.json)

[Earlier conventional silhouette sheet](Concepts/megaplane-study.svg) · [Earlier PNG](Concepts/megaplane-study.png) · [Conventional parameters](Concepts/study-parameters.json)

## Decisions made for this study

- Investigate a subsonic, wing-borne carrier/transport with **indirect fission-heated airbreathing propulsion** as the preferred 2055 flagship. Fusion is superseded by the user's fission direction. A complete airworthy nuclear installation remains an explicit programme-level assumption.
- Use air-started strategic missions as the first future feasibility experiment; runway operation remains a separate requirement to investigate.
- Keep airborne launch, recovery and ground-effect operation separate decisions. Nuclear propulsion requires its own shielding, installed-mass, operating and shutdown-cooling gates.
- Treat point defense and kinetic shielding as layered physical systems with finite capability: warning, EW/decoys, DIRCM, limited interception, localized protection and damage tolerance.
- Treat the carrier as a shared faction expedition, with all support roles available together subject to actual stock, geometry and handling constraints. Capture requires deployed ground elements; proximity supplies no extra capture, service or omniscient-detection effect.
- Conserve personnel, craft and delivered supplies through deployment, service, recovery, losses and reconnects. The carrier's chemical contingency reserve is not its transferable fuel stock.
- Preserve native game authority for flight, damage, stores, ownership and replication. Reuse Skylark's integration lessons rather than its VTOL configuration or identity.
- Make scale legible through cockpit windows, human-size access points, landing bogies, engine service panels and subordinate aircraft. The supplied vector sheet is an original schematic, not a production model or aerodynamic drawing.

## Repository and evidence boundaries

The existing repository deliberately keeps module Markdown local through the root `.gitignore`. This dossier follows that convention; it has not changed ignore policy, staged files, or published anything. The SVG and JSON are ordinary untracked concept assets until explicitly included in a later change.

Skylark source and its bundle were already dirty during the pipeline audit. Local source and records were inspected, but no build, render of a game asset, editor operation, game session or multiplayer test was run for Megaplane. Historical Skylark results belong to their recorded artifacts and cannot validate this aircraft. The concept sheets are original rendered vector diagrams, not production aircraft renders.
