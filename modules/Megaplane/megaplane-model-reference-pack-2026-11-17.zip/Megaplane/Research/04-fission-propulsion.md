# Fission propulsion — a defensible 2055 architecture

**Research date:** 2026-11-17. **Direction:** fission, following the user's correction. This replaces fusion as the preferred energy concept. The task remains research and concept development; this document is not a reactor or engine construction specification.

## Main conclusion

Study an **indirect-cycle fission-heated airbreathing aircraft**: an isolated nuclear heat source supplies heat to turbine/fan powertrains through heat-transfer equipment. Incoming engine air remains separate from the reactor-side system. Chemical propulsion supports startup, contingency operations and selected high-demand conditions. Electrical generation serves aircraft systems and mission equipment rather than converting the entire cruise propulsion demand into electricity.

This is a researched architecture with substantial unresolved aircraft engineering. Fission is an established energy source; an airworthy installation at this aircraft's power, mass and protection limits is not established by that fact.

## What the primary evidence actually supports

| Source and date | Evidence | Boundary |
| --- | --- | --- |
| [NACA, Aircraft Nuclear Propulsion, 1957](https://www.nasa.gov/wp-content/uploads/2024/06/aircraft-nuclear-propulsion-talk-1957.pdf) | Contemporary investigation of nuclear aircraft, including indirect thermal coupling. | Research lineage, not a flight-qualified reactor or engine. Exchangers, thermal transport and temperature limits matter. |
| [NASA TM X-2386, November 1971](https://ntrs.nasa.gov/api/citations/19710028801/downloads/19710028801.pdf) | Discusses nuclear-heated turbofans, an engine heat exchanger and nuclear/chemical operation for large aircraft. | An unbuilt aircraft study. Its dimensions and ambitions do not validate this 2055 installation. |
| [Thomas K. McCusker, Final Report: Decontamination and Decommissioning of Heat Transfer Reactor Experiment Test Assemblies HTRE-2 and HTRE-3, EGG-2575, September 1989](https://inldigitallibrary.inl.gov/PRR/81118.pdf) | Records historical nuclear aircraft propulsion work, including nuclear-heated ground engine operation in January 1956. | Direct-cycle ground demonstrations did not establish flight, crew protection or the preferred indirect cycle. |
| [GAO review B-146759, 28 February 1963](https://www.gao.gov/products/b-146759) | Federal review of the aircraft nuclear propulsion programme and its difficulties. | Useful programme history; historical spending or testing is not evidence that the complete aircraft problem was solved. |
| [DOE, What Is a Nuclear Microreactor?, 26 February 2021](https://www.energy.gov/ne/articles/what-nuclear-microreactor) | Describes approximately 1–20 MW **thermal** microreactors and transportable concepts. | Transportability does not mean airborne operation. The proposed gigawatt-class thermal installation is not an ordinary microreactor. |
| [NRC, spent-fuel storage questions and answers](https://www.nrc.gov/facilities-safety/storage-of-spent-nuclear-fuel/spent-fuel-storage-in-pools-and-dry-casks-key-points-and-questions-answers), accessed 2026-11-17 | Explains that heat remains after reactor operation stops. | The aircraft needs a dedicated decay-heat analysis; storage guidance does not size its shutdown-cooling equipment. |

The earlier [real-aircraft report](01-real-aircraft.md) also distinguishes reactor carriage from reactor propulsion. NB-36H flights cannot be presented as nuclear-powered flight.

## Architecture comparison

| Option | Why consider it | Principal burden | Position in this concept |
| --- | --- | --- | --- |
| Direct-cycle nuclear airbreathing | Shorter thermal coupling; historical ground precedent. | Engine airflow interacts directly with the nuclear heat source; servicing and contamination consequences conflict with a crewed carrier's operation. | Historical comparison. |
| **Indirect nuclear airbreathing** | Uses nuclear heat in an atmospheric turbine/fan cycle; propulsion airflow carries away substantial energy. | Heat-exchanger and transport mass, pressure losses, temperature limits, damage isolation and maintenance. | **Preferred 2055 research direction.** |
| Nuclear-electric fans | Separates generation from fan location and supports electrical power sharing. | Whole-propulsion conversion equipment, distribution, motors and very large heat-rejection systems. | Alternative to quantify, not the default. |
| Conventional chemical aircraft | Existing propulsion lineage and simpler ground operation. | Large fuel allocation and limited endurance. | Preserve as the original comparison and a risk-retirement demonstrator. |

These positions are our systems-level assessment, not source recommendations for BREAKWATER. A nuclear rocket and a spacecraft electric thruster do not supply an appropriate substitute for atmospheric air-moving propulsion.

## Why the indirect cycle helps

The conventional sizing study estimates about 2.05 MN drag at 180 m/s, or about **369 MW useful thrust power**. The power relation is described by [NASA Glenn](https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/power/). Electrical input would be larger after conversion and propulsive losses.

Generating hundreds of megawatts of propulsion electricity would require a large heat engine and its own heat sink, followed by motors and fans. Indirect airbreathing instead introduces high-grade heat into the propulsion cycle. Much of the energy that does not become useful thrust leaves in hot engine airflow and unrecovered wake energy.

That is an energy path, not disappearance of heat. Installed performance still depends on real temperature limits, exchanger losses, fan/core integration and aerodynamic drag. Shielding, structures, accessories and shutdown operation need additional cooling. The screening balance and the difference from the electric alternative are explicit in [SYSTEMS_2055.md](../Design/SYSTEMS_2055.md).

## Engineering solutions to investigate

1. **Group the nuclear-heated powertrains inboard.** Reserve the deep inner wing for protected plant and relatively short thermal connections. Four additional outboard nacelles can provide conventional assistance; the final mapping remains open. Do not assume long hot connections across the entire span are free.
2. **Separate the crew, payload and plant zones.** Define radiation protection, structural separation, heat barriers, equipment access and permissible occupancy together. Shielding must account for radiation scattered by the aircraft and atmosphere; distance and a forward-only shield do not prove adequate crew protection.
3. **Use an isolated heat-transfer architecture.** Treat the reactor-side system and engine air as separate systems. Model leakage, exchanger failure, pressure losses and heat soak; the concept does not specify reactor internals, fuel composition or a coolant recipe.
4. **Make power reduction a normal operating state.** Loss of a heat-transfer train, engine airflow or cooling capacity should cause derating and mission abort. Independent chemical capability must be demonstrated for its stated diversion/descent envelope.
5. **Provide cooling after shutdown and on the ground.** Reactor shutdown removes the main fission source but leaves residual heat. Ground support, independent energy for essential cooling and fault-tolerant monitoring belong in the aircraft concept from the start.
6. **Design for depot maintenance.** Remote inspection and replaceable equipment modules can reduce exposure and downtime. They do not make activated or contaminated equipment instantly safe, or justify exchanging a hot reactor in flight.

## 2055 plausibility boundary

Advanced materials, controls, sensors and manufacturing can improve the integration problem. They do not demonstrate a complete flight-weight fission plant or guarantee one by 2055. The proposed aircraft is a flagship experimental programme with ambitious whole-system requirements, not an assumed derivative of a transportable land reactor.

Endurance will depend on crew, equipment life, consumables, thermal limits, maintenance and mission activity as well as fuel. Nuclear energy does not justify a numerical unlimited-range claim. No radiation dose, core life, reactor lifetime, accident tolerance or emergency-flight performance is established by this dossier.
