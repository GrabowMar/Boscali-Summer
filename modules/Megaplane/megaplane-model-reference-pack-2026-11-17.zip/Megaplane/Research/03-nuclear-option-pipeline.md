# Nuclear Option aircraft pipeline — current Skylark audit

Read-only audit on 2026-11-17 in `C:/Users/marci/dev/Boscali Summer`. Skylark and unrelated systems already contained concurrent edits. No build, game session, editor operation or deployment was performed for this dossier.

## Skills inspected

- Repository [boscali-nomod](../../../.agents/skills/boscali-nomod/SKILL.md): select the correct checkout, use bounded game-code context and distinguish build, flight, visual and multiplayer evidence.
- Repository [nomodkit](../../../.agents/skills/nomodkit/SKILL.md): current command names, read-only game inspection, sandbox use and exact-artifact reporting.
- Local `C:/Users/marci/.codex/skills/blender-expert/SKILL.md`, `blender-hard-surface/SKILL.md`, `blender-uv-baking/SKILL.md` and `blender-texturing-shading/SKILL.md`: measured stages, visual review, editable mechanical forms, density/UV/bake checks and material review.
- Toolkit `C:/Users/marci/dev/nomodkit/skill/blender-asset-pipeline/SKILL.md` and its `reference/aircraft-anatomy.md`: native component anatomy and export conventions. Its generic conversion helper is not a substitute for the proven aircraft export/round-trip path.

No applicable ancestor/root or Skylark `AGENTS.md` was found. Existing Markdown and art-source ignore rules explain why ordinary `rg --files` omits many useful local references; use `rg --files -uuu` for a later audit.

## Choose the integration route deliberately

The toolkit's `code context "custom aircraft native aerodynamics Blueprinter Unity FBX"` identifies Blueprinter `.nobp` aircraft definitions/prefabs and `OpAddAircraftToHangars` as one route. **Skylark uses another concrete route:** an embedded original-art bundle plus runtime cloning and refitting of native aircraft systems, followed by catalogue and network-prefab registration.

Do not describe the Skylark artwork bundle as a finished native aircraft prefab. Its authored content is transforms, meshes, renderers, materials and textures. Runtime integration supplies native physics, damage, cockpit, pilot/seat, weapons and networking.

`Core/BoscaliMod.cs` composes modules through `Compose`, including `new SkylarkModule()`. `BoscaliSummer.csproj` compiles `modules/**/*.cs` automatically. Megaplane contains **no placeholder C#** and makes no composition or project-file change.

## Concrete implementation map

All links below point to the current Skylark precedent, not a proposed dependency on its classes.

| Concern | Live source and mechanism | Megaplane implication |
| --- | --- | --- |
| Lifecycle | [SkylarkModule.cs](../../Skylark/SkylarkModule.cs), `Install`, scene services and patch list | Give the later module its own lifecycle; fail cleanly when assets or donor content are unavailable. |
| Definition / donor | [SkylarkTemplate.cs](../../Skylark/SkylarkTemplate.cs), `Ensure`, `Build`; donor key `VTOLTrainer1` | Inspect heavy fixed-wing donors rather than copying VTOL behavior. Append catalogue entries without shifting native identities. |
| Network prefab | `SkylarkPrefabPatch` on `NetworkManagerNuclearOption.RegisterPrefabs` | Allocate a unique aircraft key and prefab hash; matching peers require matching content. Never reuse Skylark's identity. |
| Mass and islands | `SkylarkTemplate.RefitAirframe` | Preserve native joints/damage ownership while recomputing masses, COM and inertia for explicit load cases. |
| Aero initialization | [SkylarkAerodynamics.cs](../../Skylark/SkylarkAerodynamics.cs), `Configure`, `Prepare`, `SkylarkAeroInitializePatch` | Use registered airfoils, measured areas and forces relative to each rigidbody COM. Supply nonzero collider extents before initialization. |
| Controls / engines | `SkylarkTemplate.RefitControls`, `RefitPropulsion`; native engines/nozzles; [SkylarkFlightMode.cs](../../Skylark/SkylarkFlightMode.cs) | Fixed-wing authority, engine count, performance curves and autopilot need a new design. |
| Collision / damage | [SkylarkGeometry.cs](../../Skylark/SkylarkGeometry.cs), `Refit`, `SkylarkHitbox`, `SkylarkDamageGroup`, `SkylarkCollisionFilter` | Use simple convex surrogates, avoid duplicate blast application, suppress intact self-contact and restore debris contacts. |
| LOD ownership | `SkylarkGeometry.RestoreLods` | Bind visibility to the appropriate damage island so detached pieces retain their art and LOD. |
| Gear | `SkylarkTemplate.RefitGear` | Measure wheels, suspension, hinges and lowest deployed tread. A hangar/spawn offset is geometry-dependent. |
| Stores | [SkylarkWeapons.cs](../../Skylark/SkylarkWeapons.cs), `Refit`; native hardpoints, mounts and loadout arrays | Station order is a mission/network contract. A carried aircraft is not automatically a weapon store. |
| Hangars | [SkylarkHangars.cs](../../Skylark/SkylarkHangars.cs), `Include` and native hangar checks | Preserve HQ, busy and damage restrictions. Size survey must precede availability changes. |
| Cockpit | [SkylarkCockpit.cs](../../Skylark/SkylarkCockpit.cs), `Refit` | Retain native pilot/seat and cameras at human scale; bind real TacScreen content and correct interior/exterior visibility. |
| Materials / status | [SkylarkMaterials.cs](../../Skylark/SkylarkMaterials.cs), [SkylarkStatusDisplay.cs](../../Skylark/SkylarkStatusDisplay.cs) | Supply original UV-consistent damage maps, livery behavior, status outline and masks. |
| Custom replicated state | [SkylarkNet.cs](../../Skylark/SkylarkNet.cs), protocol 2 | Authenticate sender/owned aircraft, validate intent on the host, broadcast state and support late join. Native motion inputs need no redundant transform protocol. |
| Acceptance hooks | `SkylarkAcceptance`, `SkylarkServiceAcceptance`, `SkylarkPeerProof`, `SkylarkAutomation` | Preserve existing symbols. Future Megaplane scenarios need independent assertions and evidence. |

Read-only installed-game inspection found that `AeroPart.AeroPart_OnInitialize` resolves airfoil IDs through `AircraftParameters.GetAirfoilID`; `AddAirfoils` registers profiles. Serialized clones may lose nonserialized IDs. `AircraftParameters` also contains takeoff/approach speeds, turn radii, G limit and PID reference speed: these are separate inputs, not properties inferred from a larger mesh.

## Asset contract to reuse, with new measurements

The concrete local references are [Skylark artwork README](../../../assets/SkylarkVTOL/README.md), its `Source/` scripts and [Unity authoring README](../../../assets/SkylarkVTOL/Source/Unity/README.md).

| Stage | Verified convention / future check |
| --- | --- |
| Blender | Metres; nose +Y, up +Z, starboard +X. No negative object scales; mirror actual geometry and verify winding. Keep pilot/seat dimensions 1:1. |
| FBX | `finish_skylark.py` uses `axis_forward='-Z'`, `axis_up='Y'`, `apply_scale_options='FBX_SCALE_NONE'`, `bake_space_transform=False`, MESH/EMPTY and tangent/custom-property data. Round-trip instead of trusting flags alone. |
| Unity | Canonical nose +Z, up +Y, starboard +X; normalized metric vertices and unit transforms. Imported child hinge frames must be measured separately. |
| Authoring project | `.nomodkit/unity-mcp`, Unity 2022.3.62f3 confirmed by `ProjectSettings/ProjectVersion.txt`; source docs identify URP 14.0.12. Recheck versions before future work. |
| Staging | `Source/Unity/SkylarkReview.cs`, `SkylarkAssetBuilder.cs`, `SkylarkBatch.cs` stage and read back geometry, indices, UVs, normals, tangents, rest poses, materials and packaged textures. Inspect the loaded staged asset before publishing. |
| Native materials | `_Basecolor`, `_Normal`, `_Metallic`, `_AO`, `_BasecolorDmg`, `_NormalDmg`, `_Livery`; active damage is `_HitPoints`. Metallic red / smoothness alpha; color/emission sRGB and data maps linear. Do not assume ORM or roughness packing. |
| Visibility / damage | Original per-part art, cockpit modes, moving surfaces, damage islands and LOD selection need coordinated ownership. Keep donor-reference extraction out of packaged dependencies. |

Skylark's 0.1 mm normalization tolerance is its existing asset contract, not an automatically suitable global tolerance for a 240 m aircraft. Establish tolerances based on anchor accuracy, large mesh coordinates and actual gameplay needs. Investigate native origin shifting, `GlobalPosition`, detached parts and payload release near map boundaries before claiming precision is adequate or inadequate.

For later asset work use the skill review loop: numeric brief → silhouette/structural layout → pivots and mechanical sweeps → shading/topology → UV/materials → LOD/collision → FBX round trip → staged loaded-bundle review → game evidence. Render and inspect each accepted stage. Generic prop/fighter triangle and atlas defaults are not a giant-aircraft budget.

## Recent Skylark evidence and its limits

The following files were inspected during this audit; the associated scenarios were **not rerun**:

- `assets/SkylarkVTOL/Review/validation.json`: 26 asset checks true; 162,560 LOD0 and 3,236 LOD1 triangles; 153 meshes and 38 empties; 11.633 × 8.234 × 3.112 m.
- `Review/fbx-roundtrip.json`: `ok: true`, matching dimensions and no negative-scale/inversion entries.
- `Review/unity-2026-11-16/bundle-release.json`: published 2026-11-17 08:27 UTC, 44,517,173 bytes. The bundle hash checked during this audit matched `803989635ff8f3274f84bbc6b5ca45b18d19aca5e91e1c15e6a0d64b27105298`.
- Current source: 3,100 kg empty, 1,000 kg fuel, 62 kN installed game thrust. These supersede older 16 November figures.
- [VALIDATION-2026-11-17.md](../../Skylark/VALIDATION-2026-11-17.md), second pass: records all ten Skylark scenarios passing on 1.15× art, including full-fuel STRIKE and 60%-fuel SEAD forward-flight variants.
- That latest record explicitly leaves protocol-2 multiplayer and AUTO tilt through 20–60 m/s unexercised. The older [16 November peer proof](../../Skylark/VALIDATION-2026-11-16.md) belongs to an earlier build and cannot validate newly added custom state.

Some artwork/Unity README counts and hashes are stale. Prefer concrete dated reports and actual artifact hashes. These observations are a snapshot of a shared evolving checkout, not continuing guarantees.

## Giant-aircraft constraints that the precedent does not solve

Map turns, stock hangar geometry, apron clearance, native AI, multi-million-kilogram complex physics, engine-out behavior, broad compound collisions, giant bounds/culling, tiled/multi-atlas native livery, network traffic and airborne payload operations all need targeted experiments. More visual parts need not mean more simulated rigidbodies. Triangle count and offline images cannot establish live performance.

Use `nomod code context`, then inspect cited symbols with `code members/source/refs` before future patches. Later sandbox commands should pass an explicit `--mod-root` and a dedicated instance. A transport peer smoke test and a feature-specific host/client test answer different questions. See [development gates](../Design/DEVELOPMENT_GATES.md) for the proposed order.
