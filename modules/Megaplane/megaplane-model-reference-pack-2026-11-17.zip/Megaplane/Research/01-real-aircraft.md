# Real aircraft — demonstrated scale and unbuilt ambition

Researched 2026-11-17. Read status before comparing numbers. **CL-1201 and Pelican are unbuilt concepts; Roc and An-225 have flown.** A design target, a certified limit and an achieved mission are different evidence. All `t` below are metric tonnes; pounds are converted at 0.45359237 kg/lb.

## Comparison

| Reference | Status / evidence | Geometry | Mass / capacity, with meaning preserved |
| --- | --- | --- | --- |
| Lockheed CL-1201 research lineage | Late-1960s proposal. NASA reproduces a related Lockheed study drawing and cites LR-22802 (12 September 1969); the reproduced drawing does not itself print CL-1201. | 340 m span, 170.7 m length, 46.6 m height; 11,630 m² wing area in the drawing. | Approximately 5.4 kt **proposed gross mass**. Drawing table: 5,375,000 kg; caption: 5,450 metric tons / 6,000 short tons. Preserve this discrepancy rather than presenting false precision. |
| Boeing Pelican ULTRA | Land-based wing-in-ground-effect transport proposal; no full-size flight demonstration. | 500 ft / 152.4 m span; 400 ft / 121.92 m length. | Study MTOW 6.00 million lb / 2,722 t; maximum payload 2.80 million lb / 1,270 t; operating empty mass 2.16 million lb / 980 t. These maxima do not define one simultaneous fuel/payload condition. |
| Stratolaunch Roc | Built and flown; first flight 13 April 2019. Used as an air-launch test platform. | 385 ft / 117.35 m span; 238 ft / 72.54 m length. | Published MTOW 1.3 million lb / 589.7 t; payload capacity 550,000 lb / 249.5 t; six turbofans. Capacity is not a claim that every test flight carried it. |
| Antonov An-225 Mriya | Built, flown and used commercially. First flight 21 December 1988. The completed aircraft was destroyed in 2022. | 88.4 m span; 84 m length; 18.2 m height; 905 m² wing area. | Historic MTOW 640 t; maximum payload 250 t; six turbofans. Cargo compartment approximately 43.3 × 6.4 × 4.4 m. |

Primary references: [NASA TM X-2386, Figure 4, printed page 4 / PDF page 6](https://ntrs.nasa.gov/api/citations/19710028801/downloads/19710028801.pdf), [Boeing engineer Bob Liebeck's 2004 MIT presentation, slides 13–14](https://ocw.mit.edu/courses/16-886-air-transportation-systems-architecting-spring-2004/f1f74907f3c14108bbc6c121d95679c5_11_daebc.pdf), [Scaled Composites Roc project](https://scaled.com/portfolio/stratolaunch/), [Stratolaunch Roc](https://www.stratolaunch.com/vehicles/roc/), [Antonov history](https://www.antonov.com/en/history/an-225-mriya), [historic Antonov brochure](https://www.antonov.com/en/file/V5hQc2hGrJGRs), [Ukroboronprom's 2022 news archive](https://ukroboronprom.com.ua/en/news?page=3).

## CL-1201 — airborne infrastructure, not a verified specification sheet

NASA's contemporary report discusses nuclear-heated turbofans and optional chemical lift engines. Its related drawing is useful for wing depth, a large centerbody and distributed support. The original Lockheed LR-22802 report was not retrieved. [NASA report](https://ntrs.nasa.gov/api/citations/19710028801/downloads/19710028801.pdf).

Frequently repeated claims about 182 lift engines, 22 fighters, 41-day endurance, reactor output and hundreds of crew are **not verified by the material inspected**. They are excluded from the concept requirements. The later [Brewer paper, The Potential of Large Aircraft (1982)](https://doi.org/10.2514/6.1982-804) was identifiable, but its full text was inaccessible.

Our design inference: borrow the sense of an aircraft containing infrastructure and its visibly deep structure. Nuclear propulsion must remain an explicit technology branch with shielding, thermal management, mass and emergency consequences. The [Smithsonian's NB-36H account](https://airandspace.si.edu/air-and-space-quarterly/issue-14/nuclear-bomber) provides a useful distinction: its operating reactor did not propel the aircraft. Reactor carriage does not establish nuclear-powered flight.

## Pelican — payload comes with an operating regime

Boeing's presentation predicts lift/drag of 21 outside ground effect and 36 at 20 ft. It predicts 10,000 nmi in ground effect versus 6,500 nmi in free air **at 1.5 million lb payload**, not maximum payload. Fold-width and loading drawings make the ground-infrastructure problem visible. All are study figures. [Boeing/MIT slides](https://ocw.mit.edu/courses/16-886-air-transportation-systems-architecting-spring-2004/f1f74907f3c14108bbc6c121d95679c5_11_daebc.pdf).

Our design inference: decide free-flight versus sea-skimming doctrine before sizing. Extreme low-altitude efficiency creates wave, obstacle, bank-clearance and route constraints. A game implementation would need verified native support or an explicitly designed new mechanic; low flight alone is not Pelican performance.

## Roc — a mothership with understandable geometry

Roc's twin fuselages and center-wing carriage make the carried vehicle's location legible. Its builder discusses fabrication choices behind the straight wing and flat-sided fuselages. The [builder's photographs](https://scaled.com/portfolio/stratolaunch/) and [operator's vehicle page](https://www.stratolaunch.com/vehicles/roc/) are the strongest visual references here.

Our design inference: reserve a real payload envelope, a clear release path and an explainable structural load path. Separate aircraft carriage from aerial retrieval. The latter is not demonstrated by Roc's mission.

## An-225 — make giant logistics visible

The historic operator brochure shows nose access, kneeling gear, loading equipment and external-payload accommodation. Its prediction of service until 2033 is obsolete after the 2022 destruction; use it only for historic dimensions and handling descriptions. [Antonov brochure](https://www.antonov.com/en/file/V5hQc2hGrJGRs).

Antonov describes its home test airfield with a 3,500 × 56 m runway and infrastructure for aircraft up to 650 t. This is an infrastructure example, **not a universal An-225 takeoff-distance requirement**. [Antonov services](https://antonov.com/en/services).

Our design inference: gear, loading access, ramps, payload density and pavement matter as much as wingspan. Do not grant a 2,400 t concept compatibility with ordinary Nuclear Option airfields based on the An-225's runway example.

## What carries into the original concept

| Keep | Investigate before promising |
| --- | --- |
| Deep lifting structure and distributed mission mass | Bending, torsion, flutter and trim over the complete payload/fuel envelope |
| Separate propulsion and maintenance access | Engine-out yaw, actual cruise thrust, fuel volume and thermal limits |
| Human-scale windows, gear and service details | Airport, apron, taxi and map fit at full scale |
| A finite useful payload with a clear operating job | Release clearance, wake interaction, authority and recovery |

The preferred 240 m-span concept lies beyond the demonstrated span of Roc and far above An-225's mass. It is an engineering stretch informed by these aircraft, not a claim of near-term feasibility. The linked source figures and photos remain external references; none is packaged as original art.
