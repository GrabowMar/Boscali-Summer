# Fictional aircraft — spectacle with a job

Researched 2026-11-17, after establishing the real-aircraft comparison. Fiction supplies visual and encounter references; it supplies no physical validation. The design lessons below are our interpretation, not claims made by the source creators.

## Reference findings

| Reference | Supported fictional premise | Useful interpretation for Megaplane | Capability requiring a separate decision |
| --- | --- | --- | --- |
| Arsenal Bird, Ace Combat 7 | Unmanned aircraft with electrically driven propellers, energy supplied from the Space Elevator and airborne resupply. | A single distant silhouette, repeated propulsion units and accompanying small aircraft can establish scale before surface detail becomes visible. | External energy infrastructure, extreme endurance and protective barriers. |
| Aigaion, Ace Combat 6 | Aerial carrier and missile platform accompanied by fighter, electronic-support and fire-support aircraft. | Build a strategic operation around the flagship. Escort and support aircraft give players useful jobs and keep the carrier dependent on other units. | A carrier that also replaces every bomber, fighter and support aircraft. |
| Gleipnir, Ace Combat X | Strategic airship with optical camouflage and fictional shock weapons. | Different visible systems can create different encounter weaknesses. Damage to propulsion, sensors or mission equipment should have distinct consequences. | Optical invisibility and superweapons; even the reference's aircraft category requires care. |
| Mobura, Ace Combat 3 | Carries two Remora parasite fighters and retrieves them in flight; limited own offensive capability. | A small subordinate force is a stronger starting brief than an unlimited drone swarm. Draw carriage clearances and release geometry before decorating the bay. | Aerial recovery; successful release would not establish successful retrieval. |

These fictional premises come from Bandai Namco's [official ACES CHRONICLE weapons retrospective](https://acecombat.jp/en/chronicle/weapons/). The publisher's [Arsenal Bird trailer](https://www.youtube.com/watch?v=zwDLfywrX44) is a primary visual reference. Canonical dimensions are intentionally omitted: the retrospective's Arsenal Bird length wording conflicts with commonly repeated span descriptions, and the concept does not need that ambiguity resolved.

| Additional reference | What the source establishes | Our visual or operational interpretation |
| --- | --- | --- |
| Kapisi / Homeworld: Deserts of Kharak | Blackbird presents a ground-based strategy game centered on fleets, resources and positioning. [Official page and gallery](https://www.blackbirdinteractive.com/kharak), [official launch trailer](https://www.youtube.com/watch?v=QZNc6Cr5O-E). | Borrow the working expedition: bridge, machinery, service access, subordinate vehicles and restrained industrial markings. This is a ground-carrier analogy, not an aerodynamic precedent. |
| S.H.I.E.L.D. Helicarrier / Marvel's Avengers | LEGO's licensed film depiction shows a flying carrier with runways, small aircraft, service equipment and rotors. [Official licensed reference](https://www.lego.com/en-us/product/the-shield-helicarrier-76042). | Familiar aircraft, doors and service vehicles make a giant vehicle's scale understandable. A naval deck on lift rotors does not provide an engineering solution for a heavy airplane. The licensed model is visual evidence, not a canonical engineering specification. |

## Apply the lessons to an original design

The working fantasy is **a strategic air expedition carried by one enormous aircraft**. The plane transports a useful mission payload, needs escorts and preparation, and exposes a few identifiable systems. Its presence changes the operation without making existing aircraft redundant.

- **From far away:** a broad wing, deep centerbody, twin tail fins and eight separated engine pods. Recognize it without decals or a HUD label.
- **During interception:** escort aircraft and a small, finite deployable force establish its role. Announced preparation and visible bay opening make an operation readable.
- **At close range:** correct-size cockpit windows, access ladders, bogies and service markings establish that this is an enormous machine rather than a scaled toy.
- **Under damage:** a failed engine group, closed mission bay or lost sensor should change the operation. Effects and debris follow actual system state.

Do not copy the reference silhouettes, textures, insignia or ship names into production assets. The concept sheet in this module is original vector artwork. No creator artwork has been downloaded or packaged.

## Supplemental source limitation

An indexed Japanese description on the [original official Ace Combat X weapons page](https://www.bandainamcoent.co.jp/cs/list/acecombat-x/mode/weapon.php) discusses Gleipnir abandoning ordinary runway landing in favor of water operation. Direct retrieval returned HTTP 403 during research. This is a useful fictional logistics prompt, not a verified water-performance specification; no engineering requirement here depends on it.
