# Technology stack for an extraordinary 2055 aircraft

**Research date:** 2026-11-17. This is a coherent package of systems to investigate, not a promise that every item will exist at the required scale by 2055.

Readiness labels below are editorial assessments, not formal numerical TRLs: **foundation** means an existing equipment family or demonstrated research principle; **extrapolation** means a plausible integration/scaling subject; **programme breakthrough** means an essential, currently unsubstantiated whole-aircraft capability.

## Technology portfolio

| System | What it contributes to BREAKWATER | Assessment and necessary limit |
| --- | --- | --- |
| Indirect fission-heated airbreathing propulsion | A central reason for long-duration strategic presence without burning chemical fuel throughout cruise. | Programme breakthrough at the required installed mass, protection and performance. Historical architecture does not establish an airworthy plant. See [fission research](04-fission-propulsion.md). |
| Chemical assistance / contingency propulsion | Startup, additional power when permitted and an emergency operating envelope. | Foundation, but integration and actual post-trip performance need measurement. It is not full nuclear-power redundancy by default. |
| Deep modular composite wing boxes | Structural depth, distributed lift and potential mass reduction. | Manufacturing extrapolation at this size. Use inspectable joints and appropriate metallic hot/load-transfer structures rather than a universal material. [HiCAM](https://www.nasa.gov/directorates/armd/aavp/hicam/about-hicam/). |
| Passive aeroelastic tailoring | Align structural deformation with the aircraft's intended load behavior. | Research foundation; flutter, divergence, damage and manufacturing variability still require analysis. [NASA Passive Aeroelastic Tailoring report, 2020](https://ntrs.nasa.gov/citations/20200001139). |
| Distributed optical strain/shape sensing | Makes a huge flexible wing measurable during flight and maintenance. | Demonstrated research foundation; coverage, calibration, survivability and diagnostic confidence require extrapolation. [NASA 2018 study](https://ntrs.nasa.gov/citations/20190033242). |
| Segmented load-alleviation surfaces | Reduce avoidable gust and maneuver loads and adjust lift distribution. | Plausible extrapolation; actuators and controls cannot replace a missing spar or passive safe margins. [NASA SciTech 2026 tunnel study](https://ntrs.nasa.gov/citations/20250011465). |
| Limited variable camber | Adapt lift distribution across cruise, payload and fuel states. | Research-led extrapolation. Mechanical segmentation is more credible than an unrestricted morphing aircraft. Shared actuators create coupled failures. |
| Health-aware flight-envelope limits | Derate bank, speed and payload operations after faults. | Plausible integration of sensors and flight control. Estimated condition is not certainty. [NASA adaptive-control research](https://ntrs.nasa.gov/citations/20090017671). |
| Distributed fault-tolerant actuation | Avoid one mechanical/electrical fault disabling every surface. | Foundation plus large-aircraft integration. Separation, local power and maintenance access cost mass. |
| Segmented electrical network | Supports mission systems, essential controls, selected electric auxiliaries and fault isolation. | Plausible extrapolation; voltage, insulation, altitude operation and fault interruption must be co-designed. [NASA circuit-breaker research](https://www.nasa.gov/eap-technology/circuit-breakers/). |
| Advanced electric machines | Compact auxiliary generation, pumps and possibly selected assist fans. | MW-class research foundation; complete-system specific power differs from motor-only targets. [NASA HEMM](https://www.nasa.gov/eap-technology/electric-machines/hemm/). |
| Selective superconducting equipment | Potentially lighter high-power generation or magnetic equipment where it earns its cooling burden. | Optional extrapolation. High-temperature superconductivity still needs cryogenic support; do not make it mandatory everywhere. |
| Solid-state power conversion and protection | Efficient distribution, controlled isolation and load prioritization. | Foundation plus scaling. Switching losses, electromagnetic compatibility and fault energy remain engineering problems. |
| Multiple temperature-level thermal systems | Keep hot plant equipment, conventional machinery, electronics and crew conditions distinct. | Essential systems engineering. Combining every heat source into one cool loop can create a much worse heat sink. [HEATheR](https://www.nasa.gov/eap-technology/heather/). |
| Integrated heat-exchanger passages | Reject accessory heat while reserving airflow, volume and maintenance access deliberately. | Extrapolation at the required duty. Include pressure loss, drag, fouling, damage and hot-day behavior. |
| Short-duration electrical / thermal buffers | Absorb selected transients without requiring every source to follow them instantly. | Foundation; stored energy and allowable temperature are finite. Buffers cannot replace continuous plant output or cooling. |
| Distributed RF, EO and IR sensing | Coverage around the large airframe, navigation and warning. | Foundation; fusion of observations still has uncertainty, occlusion and weather limits. See [protection research](06-defense-and-survivability.md). |
| EW, decoys and DIRCM | Realistic first layers of aircraft self-protection. | Foundation; different threats require different countermeasures, with finite supplies and effectiveness. |
| Limited physical point defense | Makes the giant a defended strategic asset rather than a passive target. | Aircraft integration extrapolation; finite capacity, obscured views, debris and heat remain relevant. No universal protective bubble. |
| Localized kinetic protection | Protect vital compartments and improve damage tolerance without armoring every square metre. | Foundation; threat-specific protection remains unquantified. Structure, redundancy and separation are part of survivability. |
| Fire isolation and leak monitoring | Prevent an isolated failure becoming a whole-aircraft loss. | Foundation; nuclear, chemical, electrical and payload hazards need distinct boundaries and detection. |
| Digital structural and maintenance record | Connect measured loads, inspections and component history to service decisions. | Plausible extension of digital engineering. A model is not a replacement for inspection or a guarantee of remaining life. [HiCAM](https://www.nasa.gov/directorates/armd/aavp/hicam/about-hicam/). |
| Robotic inspection and service access | Inspect large internal spaces and hot/inaccessible equipment while reducing crew exposure. | Plausible integration; maintenance equipment and access paths consume mass and volume. No automatic repair of major combat damage. |
| Automated payload handling | Move cargo and small craft predictably within measured structural and COM limits. | Foundation plus aircraft-specific integration. Airborne recovery remains a separate programme. |
| Crew endurance and supervisory automation | Support long sorties with rest, environmental control and workload management. | Foundation plus integration. Keep a clear human authority model, independent essential controls and a finite endurance budget. |

## What the underlying programmes have demonstrated

NASA's [2018 load-redistribution work](https://ntrs.nasa.gov/citations/20190033242) used independently actuated surfaces and more than 1,800 fiber-optic strain sensors on a small test aircraft. The study discusses additional load-alleviation applications; it does not prove a 240 m wing. A [flexible transport-wing study deposited in 2025 for SciTech 2026](https://ntrs.nasa.gov/citations/20250011465) reports experimental control work in a wind tunnel. Both are useful foundations for an instrumented, actively managed wing, with very different scales and test conditions from BREAKWATER.

NASA's [HiCAM programme, updated June 2026](https://www.nasa.gov/directorates/armd/aavp/hicam/about-hicam/) investigates faster composite manufacture, including thermoplastic and thermoset processes, inspection and digital engineering. This supports an industrial development story, not a fixed percentage mass saving. Do not sum independent programme benefit percentages into a fictitious total aircraft improvement.

NASA's [F-15 adaptive-control research, 6 April 2009](https://ntrs.nasa.gov/citations/20090017671) includes improvements under simulated failures and earlier unsatisfactory behavior. It supports carefully tested control reallocation, not an AI that can stabilize arbitrary physical damage.

The [HEMM motor page](https://www.nasa.gov/eap-technology/electric-machines/hemm/) describes a 1.4 MW research machine with targets of 16 kW/kg and 99% efficiency. Those are not the mass and efficiency of an installed powertrain, and do not validate dozens-of-megawatts aircraft hardware. [HEATheR](https://www.nasa.gov/eap-technology/heather/) explicitly couples electric architecture with cooling mass and drag. Selective electrification is therefore preferred to declaring every function electric.

## Optional optimizations, not required miracles

- **Boundary-layer ingestion:** NASA's detailed [2022 STARC-ABL reassessment](https://ntrs.nasa.gov/citations/20210016661) predicts 3.4% design-mission fuel saving against its advanced conventional comparison. It does not establish that benefit for this plane. Aft ingestion also competes with the release bay and can worsen inflow quality. Keep it optional.
- **Fully distributed electric cruise propulsion:** [NASA N3-X](https://www.nasa.gov/eap-aircraft-concepts/n3-x/) is an important concept precedent. Its electrical architecture does not remove plant conversion/cooling mass. Compare it to the selected indirect nuclear-airbreathing branch on complete installed performance.
- **Active flow control:** [NASA's April 2015 Boeing 757 tests](https://www.nasa.gov/news-release/nasa-wraps-up-first-green-aviation-tests-on-boeing-ecodemonstrator/) support aerodynamic research, not ballistic protection.
- **Signature management:** sensible shaping, equipment placement and controlled emissions can be studied. A huge hot nuclear-heated aircraft must not be declared invisible across radar, infrared and visual observation.

## Make the technology visible in the art

The defining forms should be a deep load-bearing wing, protected inboard power islands, substantial engine heat-transfer housings, accessory cooling passages, segmented surfaces and inspectable seams. Sensor windows, defensive apertures, decoy access, service routes and human-scale crew spaces should have recognizable functions.

The aircraft can be a marvel because these systems work together: structural sensors inform load limits, nuclear heat supports propulsion, independent chemical systems support restricted contingency operation, and protection preserves selected vital functions. Extra technology must earn its mass, power, heat, crew workload and maintenance allowance.
