# Invasion-carrier integration audit

**Audit date:** 2026-11-17, current shared checkout. Read-only source inspection and bounded installed-game code queries; no build, game run or feature acceptance. Paths and protocols below are a snapshot, not future contracts. Relevant UrbanCombat, Vanguard, Support, Wing and Command instructions were read.

The required [gameplay role](../Design/GAMEPLAY_ROLE.md) can draw on several existing systems. Their names alone do not establish the carrier behavior. [EMBARKED_FORCE.md](../Design/EMBARKED_FORCE.md) makes the new conservation and lifecycle requirements explicit.

## Infantry, deployment and ground objectives

| Live source | Existing behavior | Carrier-specific work still required |
| --- | --- | --- |
| [AirAssaultController.cs](../../UrbanCombat/Runtime/AirAssaultController.cs), `DeployHalo`, `DeployFastRope`, `ConsumeTroops`, `RefillTroops` | Uses finite native `MountedTroops.ammo`, updates carried mass/capture strength and resolves insertion. | Embarked roster, delegated dispatch, transport custody and casualty/survivor accounting. |
| `MountedTroopsFirePatch`, `HaloGlidePlan`, `FastRopePlan` | Hooks troop stores and supplies deterministic cosmetic insertion motion with host outcomes. | A carrier bay, general transport movement and actual recoverable personnel identities. |
| [ZoneGarrisonManager.cs](../../UrbanCombat/Runtime/ZoneGarrisonManager.cs), `TryOccupyBuilding`, `TryDeployEncampment`, `TryReleaseOccupation` | Native damageable defenses and tracked building/position occupancy. | Building occupation records do not contain a personnel headcount. Occupancy is not automatic base capture. |
| [InfantryEncampmentBuilder.cs](../../UrbanCombat/Runtime/InfantryEncampmentBuilder.cs), `EncampmentSite`, `DeployOrReinforce`, `TryRelease` | Strength/position records and native emplacement slots with visual infantry. | Exact survivor conservation and partial extraction. Existing `TryRelease` can return at least eight troops and removes the site. |
| [AirAssaultNet.cs](../../UrbanCombat/Networking/AirAssaultNet.cs), `ReceiveRequest` | Authenticated extraction from a sender's own aircraft and replicated extraction presentation. | General carrier/transport custody and authorized faction-officer orders. |
| [IAirAssaultObservation.cs](../../../Core/Contracts/IAirAssaultObservation.cs) | Contains both `IAirAssaultObservation` and `IAirAssaultOrders`; exposes insertion observations and extraction intents. | An insertion event is not proof of continued possession, successful occupation or objective capture. |

UrbanCombat's instructions explicitly distinguish cosmetic soldiers from combat logic: there is no reusable independent infantry squad AI in the inspected integration. Existing behavior is occupied buildings and defensive positions. A prototype may use that representation, but must not advertise room-clearing or individual soldier combat.

Current extraction can synthesize a default squad for a building occupation with no headcount. It can also remove a position before limiting recovered personnel to the receiver's capacity. Those behaviors cannot serve as the carrier's conserved expedition ledger. Native troop rearming likewise does not establish that new personnel physically arrived.

DynamicOperations insertion completion is also narrower than an invasion objective: `OperationsManager.OnLanded` accepts specific Rappel/Rooftop insertion conditions, and the observation occurs before final occupation placement. HALO does not raise the same observation. Native capture/UrbanSiege state must establish ground-objective progress independently.

`IBuildingOccupancy`, `IGroundForceReadiness`, `ILandingZone`, `ITerritoryIngress` and `ISecondaryObjectivesView` are useful seams to inspect before adding any new ones. UrbanCombat's instruction text mentions `IZoneFortificationService.TrySeize`, but the live contract currently exposes `TryFortify` / `TryFortifyFor`; do not design against the stale name.

## Aerial and ground drones

- [RemoraFlight.cs](../../Vanguard/Runtime/Loadouts/RemoraFlight.cs) supplies air-defense behavior; [MantaFlight.cs](../../Vanguard/Runtime/Loadouts/MantaFlight.cs) supplies ground strike; [KestrelDrone.cs](../../Vanguard/Runtime/Loadouts/KestrelDrone.cs) supplies reconnaissance/designation. These are missile-based native flights with host overrides, not recoverable full aircraft.
- [HamilcarFlight.cs](../../Vanguard/Runtime/Loadouts/HamilcarFlight.cs), `HamilcarUnload`, actively spawns the native `UGV1_grenade` Hexhound through `Spawner.SpawnVehicle`. `VanguardRole.Lander` and HAMILCAR flight/service paths are active source. A stale automation comment saying ground delivery is retired is not authoritative.
- HAMILCAR uses explicit landing/unload phases and a host velocity servo. This establishes an implementation precedent, not loaded-content acceptance, a carrier bay or unassisted aircraft-flight evidence. References to other native ground-UAV definitions do not mean HAMILCAR carries them.
- [DroneRoster.cs](../../Vanguard/Runtime/DroneRoster.cs) is a live-flight view on peers; `VanguardRegistry` is host-only. `IDroneCommand` and `DroneLinkService` support the local pilot's existing drone interaction.
- The inspected Vanguard command receiver, protocol 5, validates a drone against the sender's **own aircraft** and link conditions. A faction commander ordering a carrier's AI force requires new explicit authority/delegation, not bypassing that check.

Recoverable drone bays, reusable craft identity, stock-bound repair/reload and a mixed-fleet manifest are new behavior. Do not reinterpret a missile despawn or arrival near the carrier as successful recovery.

## Rearm and refuel

The strongest precedent is [SkywellService.cs](../../Vanguard/Runtime/SkywellService.cs), with [skywellPit.cs](../../Vanguard/Runtime/Loadouts/skywellPit.cs), [skywellStations.cs](../../Vanguard/Runtime/Loadouts/skywellStations.cs), [SkywellZone.cs](../../Vanguard/Domain/SkywellZone.cs) and [SkywellNet.cs](../../Vanguard/Networking/SkywellNet.cs). Current SKYWELL network protocol is 6.

**The live service is formation service with a tethered tender, not receiver docking.** Older terminology in `DockScope` must not override the active state machine. The receiving pilot retains flight control.

| Current precedent / limit | Consequence |
| --- | --- |
| Overspeed warning / AI auto-deploy limit 140 m/s; explicit deployment permits up to 160 m/s, with automatic reel above 160 m/s | Incompatible with the carrier's 180 m/s reference cruise. Establish a separate validated service track or redesign. |
| One receiver per kit, with relative-position/velocity/roll and hold/interruption conditions | Multiple carrier service channels require new geometry, scheduling and failure checks. |
| Native `Aircraft.CanRefuel`: needs fuel, radar altitude ≤5 m, speed ≤1 m/s; ordinary `Refueler` checks it | Attaching a native refueler to the carrier does not create airborne servicing. SKYWELL applies its own airborne gates before invoking native service. |
| `CommitFuel` fills through native `Refuel`, then clamps remaining kit stock | A nearly empty kit can top off more fuel than remains. Strict partial transfer is new work. |
| Generic handoff/cassette tokens for `CommitRearm` | Useful service precedent, not typed missile/belt inventories. A defined full reload kit can be a stock item; a universal token cannot establish conservation. |
| Kit restock resets near a friendly field | Does not debit a real depot. Carrier replenishment must use an authoritative supply transaction. |
| `SkywellState.FuelKg` is `ushort` | The proposed 70,000 kg transferable stock exceeds that field's maximum. Carrier-scale quantity representation and versioning need deliberate design. |

Installed native `Rearmer.ProcessRearmRequest` accounts capacity using `WeaponInfo.massPerRound` and charges allocation. It does not establish a typed physical magazine. Preserve native faction/station eligibility while implementing the carrier's additional resource rules. Cargo/troop stores must not become ordinary reload stock.

For ground support, [SofService.Ops.cs](../../Support/Runtime/SofService.Ops.cs) and [CyberAnchorSpawner.cs](../../Support/Runtime/CyberAnchorSpawner.cs) resolve and spawn real native rearmer/refueler vehicles near held positions. This is a physical service-point precedent, not proof that those vehicles were embarked, delivered or debited from carrier cargo.

## Artillery must originate aboard

[Support ArtilleryAction.cs](../../Support/Runtime/Actions/ArtilleryAction.cs) is an OPS orbital-style action: it spawns a missile above the selected impact point and validates its own SPACE/TASKED transaction. It is not a physical gun aboard the requesting aircraft.

Use its authorization/lifecycle lessons where appropriate, but the carrier needs actual mounted weapon stations, a native projectile origin and ownership, onboard magazines, aircraft-relative firing geometry and host-validated requests. Do not spend an existing remote Support resource while pretending the carrier fired a shell. A ground observation is not an authorization to fire.

## AWACS through actual faction knowledge

Read-only installed-game inspection found the native chain:

`Radar.RadarCheck → DetectorManager.RequestRadarCheck → DetectionRequest.ProcessResult → Radar.CanSeeRadarReturn → TargetDetector.DetectTarget → FactionHQ.RpcUpdateTrackingInfo`.

The inspected path considers horizon/clutter, obstruction, signal/jamming and active-sensor power. It is the appropriate foundation for damageable airborne early warning, not a registry scan that reveals all enemies.

[SkylarkTemplate.cs](../../Skylark/SkylarkTemplate.cs), `RefitSensors`, shows native detector attachment to real parts. [FactionPicture.cs](../../Intel/Runtime/FactionPicture.cs) reads faction tracking; [IThreatPicture.cs](../../../Core/Contracts/IThreatPicture.cs) represents known/unknown and stale observations. WATCHTOWER's IRST/ESM and link behavior is another sensor precedent, but it is not a full AWACS search radar.

Use actual sensor events, track age, emission state, damage, coverage and faction visibility. `ITheaterStrikePicture` is currently an empty marker interface; its name does not supply a usable fire-control/contact API.

## Ownership and implementation boundaries

Megaplane should own its manifest, handling queues, local stock, role state and carrier-specific damage consequences. Existing owners retain native motion/combat, occupancy, drone behaviors, faction knowledge and their economic policy. Use shared contracts where a real boundary is needed; do not import sibling managers or predefine a broad carrier framework.

`CommandPlatform` currently has one mutable static provider assigned by Skylark. Assigning a second carrier provider would overwrite it. Compose ownership deliberately before offering platform benefits; the invasion role must not silently break Skylark.

World mutations and transfers validate once on the host. Client intents cannot name arbitrary owned units or recipients without authorization. Preserve independent deployed units on carrier loss, bounded scene cleanup, late-join state and versioned quantities. The source audit establishes useful seams and missing work; it does not establish any Megaplane capability in the running game.
